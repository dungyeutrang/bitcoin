-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: 127.0.0.1
-- Generation Time: July 5, 2016, 03:19 PM GMT
-- Server version: 5.5.5-10.1.10-MariaDB
-- PHP Version: 5.5.33

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8mb4';
SET SESSION `character_set_results`='utf8mb4';
SET SESSION `character_set_connection`='utf8mb4';
SET SESSION `collation_connection`='utf8mb4_unicode_ci';
SET NAMES 'utf8mb4';
ALTER DATABASE DEFAULT CHARACTER SET `utf8mb4` COLLATE `utf8mb4_unicode_ci`;

--
-- Database: `bitcoin`
--


-- ---------------------------------------


--
-- Table structure for table `nv4_authors`
--

DROP TABLE IF EXISTS `nv4_authors`;
CREATE TABLE `nv4_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `position` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text  COLLATE utf8mb4_unicode_ci,
  `check_num` varchar(40)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_authors`
--

INSERT INTO `nv4_authors` VALUES
(1, 'ckeditor', 1, 'adobe,application,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', '', 0, '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_config`
--

DROP TABLE IF EXISTS `nv4_authors_config`;
CREATE TABLE `nv4_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_module`
--

DROP TABLE IF EXISTS `nv4_authors_module`;
CREATE TABLE `nv4_authors_module` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_authors_module`
--

INSERT INTO `nv4_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, 'fa14f450f1289f2da4d522f5bb244728'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, '71598e405bc00da342964ce7957661e5'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, 'bc5ae617bba144213f3ce22d809e24b9'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, 'cfd9f02eaa00631391e9e901c70f9237'), 
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, '54fc5571e9e5efb5977e4d3d2701c04e'), 
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, '4c2b90c232ada6b43776f9b1afb0eaa5'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, 'cb64be27d01ec152e2c93ef862236573'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '42f9faba1f9e24ca66c078df0507f34a'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, '3160cd4ea69fc4b3d4403b6f65979ebc'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, '5cb72d988eaf154b37905acb8f2a711d'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, '07d535b85d4328ed0157aae901331fc3');


-- ---------------------------------------


--
-- Table structure for table `nv4_banip`
--

DROP TABLE IF EXISTS `nv4_banip`;
CREATE TABLE `nv4_banip` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_click`
--

DROP TABLE IF EXISTS `nv4_banners_click`;
CREATE TABLE `nv4_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_country` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_ref` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_clients`
--

DROP TABLE IF EXISTS `nv4_banners_clients`;
CREATE TABLE `nv4_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(80)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `yim` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploadtype` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_plans`
--

DROP TABLE IF EXISTS `nv4_banners_plans`;
CREATE TABLE `nv4_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `form` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_banners_plans`
--

INSERT INTO `nv4_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 575, 72, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 212, 800, 1), 
(3, '', 'Quang cao Phai', '', 'random', 250, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_rows`
--

DROP TABLE IF EXISTS `nv4_banners_rows`;
CREATE TABLE `nv4_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_ext` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_mime` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageforswf` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `click_url` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_blank',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_banners_rows`
--

INSERT INTO `nv4_banners_rows` VALUES
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 212, 400, '', '', 'http://vinades.vn', '_blank', 1467731932, 1467731932, 0, 0, 1, 2), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh.jpg', 'png', 'image/jpeg', 575, 72, '', '', 'http://webnhanh.vn', '_blank', 1467731932, 1467731932, 0, 0, 1, 1), 
(4, '123host_Nukeviet', 3, 0, '123host_nukeviet.jpg', 'jpg', 'image/jpeg', 250, 250, '', '', 'http://event.123host.vn/link/out/338', '_blank', 1453194858, 1453194858, 0, 0, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_config`
--

DROP TABLE IF EXISTS `nv4_config`;
CREATE TABLE `nv4_config` (
  `lang` varchar(3)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sys',
  `module` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `config_value` text  COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_config`
--

INSERT INTO `nv4_config` VALUES
('sys', 'site', 'closed_site', '0'), 
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'mailer_mode', ''), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'global', 'ssl_https', '0'), 
('sys', 'global', 'notification_active', '1'), 
('sys', 'global', 'notification_autodel', '15'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '2097152'), 
('sys', 'global', 'upload_checking_mode', 'strong'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowuserloginmulti', '0'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '0'), 
('sys', 'global', 'allowuserpublic', '1'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'en'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_optional', '0'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'rewrite_op_mod', ''), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', ''), 
('sys', 'global', 'timestamp', '1'), 
('sys', 'global', 'openid_processing', '0'), 
('sys', 'global', 'captcha_type', '1'), 
('sys', 'global', 'version', '4.0.29'), 
('sys', 'global', 'whoviewuser', '2'), 
('sys', 'global', 'facebook_client_id', ''), 
('sys', 'global', 'facebook_client_secret', ''), 
('sys', 'global', 'google_client_id', ''), 
('sys', 'global', 'google_client_secret', ''), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'user_check_pass_time', '1800'), 
('sys', 'global', 'auto_login_after_reg', '1'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'nv_unick_type', '4'), 
('sys', 'global', 'nv_upass_type', '2'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'define', 'nv_unickmin', '4'), 
('sys', 'define', 'nv_unickmax', '20'), 
('sys', 'define', 'nv_upassmin', '8'), 
('sys', 'define', 'nv_upassmax', '20'), 
('sys', 'define', 'nv_gfx_num', '6'), 
('sys', 'define', 'nv_gfx_width', '150'), 
('sys', 'define', 'nv_gfx_height', '40'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '0'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, s, sub, sup, table, tbody, td, th, tr, u, ul, ol, iframe, figure, figcaption, video, audio, source, track, code, pre'), 
('sys', 'define', 'dir_forum', ''), 
('en', 'global', 'site_domain', ''), 
('en', 'global', 'site_name', 'Bitcoin'), 
('en', 'global', 'site_logo', ''), 
('en', 'global', 'site_banner', ''), 
('en', 'global', 'site_favicon', ''), 
('en', 'global', 'site_description', 'Sharing success, connect passions'), 
('en', 'global', 'site_keywords', ''), 
('en', 'global', 'theme_type', 'r,d,m'), 
('en', 'global', 'site_theme', 'default'), 
('en', 'global', 'mobile_theme', 'mobile_default'), 
('en', 'global', 'site_home_module', 'news'), 
('en', 'global', 'switch_mobi_des', '1'), 
('en', 'global', 'upload_logo', ''), 
('en', 'global', 'upload_logo_pos', 'bottomRight'), 
('en', 'global', 'autologosize1', '50'), 
('en', 'global', 'autologosize2', '40'), 
('en', 'global', 'autologosize3', '30'), 
('en', 'global', 'autologomod', ''), 
('en', 'global', 'name_show', '1'), 
('en', 'global', 'cronjobs_next_time', '1467732273'), 
('en', 'global', 'disable_site_content', 'For technical reasons Web site temporary not available. we are very sorry for that inconvenience!'), 
('en', 'global', 'ssl_https_modules', ''), 
('en', 'seotools', 'prcservice', ''), 
('en', 'about', 'auto_postcomm', '1'), 
('en', 'about', 'allowed_comm', '-1'), 
('en', 'about', 'view_comm', '6'), 
('en', 'about', 'setcomm', '4'), 
('en', 'about', 'activecomm', '0'), 
('en', 'about', 'emailcomm', '0'), 
('en', 'about', 'adminscomm', ''), 
('en', 'about', 'sortcomm', '0'), 
('en', 'about', 'captcha', '1'), 
('en', 'news', 'indexfile', 'viewcat_main_right'), 
('en', 'news', 'per_page', '20'), 
('en', 'news', 'st_links', '10'), 
('en', 'news', 'homewidth', '100'), 
('en', 'news', 'homeheight', '150'), 
('en', 'news', 'blockwidth', '70'), 
('en', 'news', 'blockheight', '75'), 
('en', 'news', 'imagefull', '460'), 
('en', 'news', 'copyright', 'Note: The above article reprinted at the website or other media sources not specify the source http://nukeviet.vn is copyright infringement'), 
('en', 'news', 'showtooltip', '1'), 
('en', 'news', 'tooltip_position', 'bottom'), 
('en', 'news', 'tooltip_length', '150'), 
('en', 'news', 'showhometext', '1'), 
('en', 'news', 'timecheckstatus', '0'), 
('en', 'news', 'config_source', '0'), 
('en', 'news', 'show_no_image', ''), 
('en', 'news', 'allowed_rating_point', '1'), 
('en', 'news', 'facebookappid', ''), 
('en', 'news', 'socialbutton', '1'), 
('en', 'news', 'alias_lower', '1'), 
('en', 'news', 'tags_alias', '0'), 
('en', 'news', 'auto_tags', '0'), 
('en', 'news', 'tags_remind', '1'), 
('en', 'news', 'structure_upload', 'Ym'), 
('en', 'news', 'imgposition', '2'), 
('en', 'news', 'auto_postcomm', '1'), 
('en', 'news', 'allowed_comm', '-1'), 
('en', 'news', 'view_comm', '6'), 
('en', 'news', 'setcomm', '4'), 
('en', 'news', 'activecomm', '1'), 
('en', 'news', 'emailcomm', '0'), 
('en', 'news', 'adminscomm', ''), 
('en', 'news', 'sortcomm', '0'), 
('en', 'news', 'captcha', '1'), 
('en', 'page', 'auto_postcomm', '1'), 
('en', 'page', 'allowed_comm', '-1'), 
('en', 'page', 'view_comm', '6'), 
('en', 'page', 'setcomm', '4'), 
('en', 'page', 'activecomm', '0'), 
('en', 'page', 'emailcomm', '0'), 
('en', 'page', 'adminscomm', ''), 
('en', 'page', 'sortcomm', '0'), 
('en', 'page', 'captcha', '1'), 
('en', 'siteterms', 'auto_postcomm', '1'), 
('en', 'siteterms', 'allowed_comm', '-1'), 
('en', 'siteterms', 'view_comm', '6'), 
('en', 'siteterms', 'setcomm', '4'), 
('en', 'siteterms', 'activecomm', '0'), 
('en', 'siteterms', 'emailcomm', '0'), 
('en', 'siteterms', 'adminscomm', ''), 
('en', 'siteterms', 'sortcomm', '0'), 
('en', 'siteterms', 'captcha', '1'), 
('en', 'freecontent', 'next_execute', '0'), 
('vi', 'contact', 'bodytext', 'If you have any questions or comments, please contact us below and we will get back to you as soon as possible.'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'dungpv20101292@gmail.com'), 
('sys', 'global', 'error_set_logs', '1'), 
('sys', 'global', 'error_send_email', 'dungpv20101292@gmail.com'), 
('sys', 'global', 'site_lang', 'en'), 
('sys', 'global', 'my_domains', 'localhost'), 
('sys', 'global', 'cookie_prefix', 'nv4c_f3rou'), 
('sys', 'global', 'session_prefix', 'nv4s_k9vH3z'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '1'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', 'wwnrYwQboFrK2A8POkRj0sMJ62MEG6BaytgPDzpEY9I,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0');


-- ---------------------------------------


--
-- Table structure for table `nv4_cookies`
--

DROP TABLE IF EXISTS `nv4_cookies`;
CREATE TABLE `nv4_cookies` (
  `name` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_counter`
--

DROP TABLE IF EXISTS `nv4_counter`;
CREATE TABLE `nv4_counter` (
  `c_type` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_val` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `en_count` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_counter`
--

INSERT INTO `nv4_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1467731973, 0), 
('total', 'hits', 1467731973, 1, 1), 
('year', '2016', 1467731973, 1, 1), 
('year', '2017', 0, 0, 0), 
('year', '2018', 0, 0, 0), 
('year', '2019', 0, 0, 0), 
('year', '2020', 0, 0, 0), 
('year', '2021', 0, 0, 0), 
('year', '2022', 0, 0, 0), 
('year', '2023', 0, 0, 0), 
('year', '2024', 0, 0, 0), 
('month', 'Jan', 0, 0, 0), 
('month', 'Feb', 0, 0, 0), 
('month', 'Mar', 0, 0, 0), 
('month', 'Apr', 0, 0, 0), 
('month', 'May', 0, 0, 0), 
('month', 'Jun', 0, 0, 0), 
('month', 'Jul', 1467731973, 1, 1), 
('month', 'Aug', 0, 0, 0), 
('month', 'Sep', 0, 0, 0), 
('month', 'Oct', 0, 0, 0), 
('month', 'Nov', 0, 0, 0), 
('month', 'Dec', 0, 0, 0), 
('day', '01', 0, 0, 0), 
('day', '02', 0, 0, 0), 
('day', '03', 0, 0, 0), 
('day', '04', 0, 0, 0), 
('day', '05', 1467731973, 1, 1), 
('day', '06', 0, 0, 0), 
('day', '07', 0, 0, 0), 
('day', '08', 0, 0, 0), 
('day', '09', 0, 0, 0), 
('day', '10', 0, 0, 0), 
('day', '11', 0, 0, 0), 
('day', '12', 0, 0, 0), 
('day', '13', 0, 0, 0), 
('day', '14', 0, 0, 0), 
('day', '15', 0, 0, 0), 
('day', '16', 0, 0, 0), 
('day', '17', 0, 0, 0), 
('day', '18', 0, 0, 0), 
('day', '19', 0, 0, 0), 
('day', '20', 0, 0, 0), 
('day', '21', 0, 0, 0), 
('day', '22', 0, 0, 0), 
('day', '23', 0, 0, 0), 
('day', '24', 0, 0, 0), 
('day', '25', 0, 0, 0), 
('day', '26', 0, 0, 0), 
('day', '27', 0, 0, 0), 
('day', '28', 0, 0, 0), 
('day', '29', 0, 0, 0), 
('day', '30', 0, 0, 0), 
('day', '31', 0, 0, 0), 
('dayofweek', 'Sunday', 0, 0, 0), 
('dayofweek', 'Monday', 0, 0, 0), 
('dayofweek', 'Tuesday', 1467731973, 1, 1), 
('dayofweek', 'Wednesday', 0, 0, 0), 
('dayofweek', 'Thursday', 0, 0, 0), 
('dayofweek', 'Friday', 0, 0, 0), 
('dayofweek', 'Saturday', 0, 0, 0), 
('hour', '00', 0, 0, 0), 
('hour', '01', 0, 0, 0), 
('hour', '02', 0, 0, 0), 
('hour', '03', 0, 0, 0), 
('hour', '04', 0, 0, 0), 
('hour', '05', 0, 0, 0), 
('hour', '06', 0, 0, 0), 
('hour', '07', 0, 0, 0), 
('hour', '08', 0, 0, 0), 
('hour', '09', 0, 0, 0), 
('hour', '10', 0, 0, 0), 
('hour', '11', 0, 0, 0), 
('hour', '12', 0, 0, 0), 
('hour', '13', 0, 0, 0), 
('hour', '14', 0, 0, 0), 
('hour', '15', 0, 0, 0), 
('hour', '16', 0, 0, 0), 
('hour', '17', 0, 0, 0), 
('hour', '18', 0, 0, 0), 
('hour', '19', 0, 0, 0), 
('hour', '20', 0, 0, 0), 
('hour', '21', 0, 0, 0), 
('hour', '22', 1467731973, 1, 1), 
('hour', '23', 0, 0, 0), 
('bot', 'googlebot', 0, 0, 0), 
('bot', 'msnbot', 0, 0, 0), 
('bot', 'bingbot', 0, 0, 0), 
('bot', 'yahooslurp', 0, 0, 0), 
('bot', 'w3cvalidator', 0, 0, 0), 
('browser', 'opera', 0, 0, 0), 
('browser', 'operamini', 0, 0, 0), 
('browser', 'webtv', 0, 0, 0), 
('browser', 'explorer', 0, 0, 0), 
('browser', 'edge', 0, 0, 0), 
('browser', 'pocket', 0, 0, 0), 
('browser', 'konqueror', 0, 0, 0), 
('browser', 'icab', 0, 0, 0), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'firefox', 0, 0, 0), 
('browser', 'iceweasel', 0, 0, 0), 
('browser', 'shiretoko', 0, 0, 0), 
('browser', 'mozilla', 0, 0, 0), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'lynx', 0, 0, 0), 
('browser', 'safari', 0, 0, 0), 
('browser', 'iphone', 0, 0, 0), 
('browser', 'ipod', 0, 0, 0), 
('browser', 'ipad', 0, 0, 0), 
('browser', 'chrome', 1467731973, 1, 1), 
('browser', 'cococ', 0, 0, 0), 
('browser', 'android', 0, 0, 0), 
('browser', 'googlebot', 0, 0, 0), 
('browser', 'yahooslurp', 0, 0, 0), 
('browser', 'w3cvalidator', 0, 0, 0), 
('browser', 'blackberry', 0, 0, 0), 
('browser', 'icecat', 0, 0, 0), 
('browser', 'nokias60', 0, 0, 0), 
('browser', 'nokia', 0, 0, 0), 
('browser', 'msn', 0, 0, 0), 
('browser', 'msnbot', 0, 0, 0), 
('browser', 'bingbot', 0, 0, 0), 
('browser', 'netscape', 0, 0, 0), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'netpositive', 0, 0, 0), 
('browser', 'phoenix', 0, 0, 0), 
('browser', 'Mobile', 0, 0, 0), 
('browser', 'bots', 0, 0, 0), 
('browser', 'Unknown', 0, 0, 0), 
('os', 'unknown', 0, 0, 0), 
('os', 'win', 0, 0, 0), 
('os', 'win10', 1467731973, 1, 1), 
('os', 'win8', 0, 0, 0), 
('os', 'win7', 0, 0, 0), 
('os', 'win2003', 0, 0, 0), 
('os', 'winvista', 0, 0, 0), 
('os', 'wince', 0, 0, 0), 
('os', 'winxp', 0, 0, 0), 
('os', 'win2000', 0, 0, 0), 
('os', 'apple', 0, 0, 0), 
('os', 'linux', 0, 0, 0), 
('os', 'os2', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'iphone', 0, 0, 0), 
('os', 'ipod', 0, 0, 0), 
('os', 'ipad', 0, 0, 0), 
('os', 'blackberry', 0, 0, 0), 
('os', 'nokia', 0, 0, 0), 
('os', 'freebsd', 0, 0, 0), 
('os', 'openbsd', 0, 0, 0), 
('os', 'netbsd', 0, 0, 0), 
('os', 'sunos', 0, 0, 0), 
('os', 'opensolaris', 0, 0, 0), 
('os', 'android', 0, 0, 0), 
('os', 'irix', 0, 0, 0), 
('os', 'palm', 0, 0, 0), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 0, 0, 0), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 0, 0, 0), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 0, 0, 0), 
('country', 'AM', 0, 0, 0), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 0, 0, 0), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 0, 0, 0), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 0, 0, 0), 
('country', 'AU', 0, 0, 0), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 0, 0, 0), 
('country', 'BA', 0, 0, 0), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 0, 0, 0), 
('country', 'BE', 0, 0, 0), 
('country', 'BF', 0, 0, 0), 
('country', 'BG', 0, 0, 0), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 0, 0, 0), 
('country', 'BM', 0, 0, 0), 
('country', 'BN', 0, 0, 0), 
('country', 'BO', 0, 0, 0), 
('country', 'BR', 0, 0, 0), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 0, 0, 0), 
('country', 'BY', 0, 0, 0), 
('country', 'BZ', 0, 0, 0), 
('country', 'CA', 0, 0, 0), 
('country', 'CD', 0, 0, 0), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 0, 0, 0), 
('country', 'CH', 0, 0, 0), 
('country', 'CI', 0, 0, 0), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 0, 0, 0), 
('country', 'CM', 0, 0, 0), 
('country', 'CN', 0, 0, 0), 
('country', 'CO', 0, 0, 0), 
('country', 'CR', 0, 0, 0), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 0, 0, 0), 
('country', 'CZ', 0, 0, 0), 
('country', 'DE', 0, 0, 0), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 0, 0, 0), 
('country', 'DM', 0, 0, 0), 
('country', 'DO', 0, 0, 0), 
('country', 'DZ', 0, 0, 0), 
('country', 'EC', 0, 0, 0), 
('country', 'EE', 0, 0, 0), 
('country', 'EG', 0, 0, 0), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 0, 0, 0), 
('country', 'ET', 0, 0, 0), 
('country', 'EU', 0, 0, 0), 
('country', 'FI', 0, 0, 0), 
('country', 'FJ', 0, 0, 0), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 0, 0, 0), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 0, 0, 0), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 0, 0, 0), 
('country', 'GF', 0, 0, 0), 
('country', 'GH', 0, 0, 0), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 0, 0, 0), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 0, 0, 0), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 0, 0, 0), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 0, 0, 0), 
('country', 'HK', 0, 0, 0), 
('country', 'HN', 0, 0, 0), 
('country', 'HR', 0, 0, 0), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 0, 0, 0), 
('country', 'ID', 0, 0, 0), 
('country', 'IE', 0, 0, 0), 
('country', 'IL', 0, 0, 0), 
('country', 'IN', 0, 0, 0), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 0, 0, 0), 
('country', 'IR', 0, 0, 0), 
('country', 'IS', 0, 0, 0), 
('country', 'IT', 0, 0, 0), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 0, 0, 0), 
('country', 'JP', 0, 0, 0), 
('country', 'KE', 0, 0, 0), 
('country', 'KG', 0, 0, 0), 
('country', 'KH', 0, 0, 0), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 0, 0, 0), 
('country', 'KN', 0, 0, 0), 
('country', 'KR', 0, 0, 0), 
('country', 'KW', 0, 0, 0), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 0, 0, 0), 
('country', 'LB', 0, 0, 0), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 0, 0, 0), 
('country', 'LR', 0, 0, 0), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 0, 0, 0), 
('country', 'LU', 0, 0, 0), 
('country', 'LV', 0, 0, 0), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 0, 0, 0), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 0, 0, 0), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 0, 0, 0), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 0, 0, 0), 
('country', 'MO', 0, 0, 0), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 0, 0, 0), 
('country', 'MU', 0, 0, 0), 
('country', 'MV', 0, 0, 0), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 0, 0, 0), 
('country', 'MY', 0, 0, 0), 
('country', 'MZ', 0, 0, 0), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 0, 0, 0), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 0, 0, 0), 
('country', 'NO', 0, 0, 0), 
('country', 'NP', 0, 0, 0), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 0, 0, 0), 
('country', 'OM', 0, 0, 0), 
('country', 'PA', 0, 0, 0), 
('country', 'PE', 0, 0, 0), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 0, 0, 0), 
('country', 'PH', 0, 0, 0), 
('country', 'PK', 0, 0, 0), 
('country', 'PL', 0, 0, 0), 
('country', 'PR', 0, 0, 0), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 0, 0, 0), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 0, 0, 0), 
('country', 'QA', 0, 0, 0), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 0, 0, 0), 
('country', 'RU', 0, 0, 0), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 0, 0, 0), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 0, 0, 0), 
('country', 'SD', 0, 0, 0), 
('country', 'SE', 0, 0, 0), 
('country', 'SG', 0, 0, 0), 
('country', 'SI', 0, 0, 0), 
('country', 'SK', 0, 0, 0), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 0, 0, 0), 
('country', 'SO', 0, 0, 0), 
('country', 'SR', 0, 0, 0), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 0, 0, 0), 
('country', 'SY', 0, 0, 0), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 0, 0, 0), 
('country', 'TJ', 0, 0, 0), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 0, 0, 0), 
('country', 'TN', 0, 0, 0), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 0, 0, 0), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 0, 0, 0), 
('country', 'TZ', 0, 0, 0), 
('country', 'UA', 0, 0, 0), 
('country', 'UG', 0, 0, 0), 
('country', 'US', 0, 0, 0), 
('country', 'UY', 0, 0, 0), 
('country', 'UZ', 0, 0, 0), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 0, 0, 0), 
('country', 'VE', 0, 0, 0), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 0, 0, 0), 
('country', 'VU', 0, 0, 0), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 0, 0, 0), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 0, 0, 0), 
('country', 'ZM', 0, 0, 0), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1467731973, 1, 1), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_cronjobs`
--

DROP TABLE IF EXISTS `nv4_cronjobs`;
CREATE TABLE `nv4_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_func` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `en_cron_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_cronjobs`
--

INSERT INTO `nv4_cronjobs` VALUES
(1, 1467731932, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1467731973, 1, 'Delete expired online status'), 
(2, 1467731932, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 0, 0, 'Automatic backup database'), 
(3, 1467731932, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 0, 0, 'Empty temporary files'), 
(4, 1467731932, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 0, 0, 'Delete IP log files'), 
(5, 1467731932, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 0, 0, 'Delete expired error_log log files'), 
(6, 1467731932, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Send error logs to admin'), 
(7, 1467731932, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 0, 0, 'Delete expired referer'), 
(8, 1467731932, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 0, 0, 'Check NukeViet version'), 
(9, 1467731932, 1440, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 0, 0, 'Delete old notification');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_about`
--

DROP TABLE IF EXISTS `nv4_en_about`;
CREATE TABLE `nv4_en_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_about`
--

INSERT INTO `nv4_en_about` VALUES
(1, 'Welcome to NukeViet 3.0', 'Welcome-to-NukeViet-3-0', '', '', 0, '', '<p> NukeViet developed by Vietnamese and for Vietnamese. It&#039;s the 1st opensource CMS in Vietnam. Next generation of NukeViet, version 3.0 coding ground up. Support newest web technology, include xHTML, CSS 3, XTemplate, jQuery, AJAX...<br /> <br /> NukeViet&#039;s has it own core libraries build in. So, it&#039;s doesn&#039;t depend on other exists frameworks. With basic knowledge of PHP and MySQL, you can easily using NukeViet for your purposes.<br /> <br /> NukeViet 3 core is simply but powerful. It support modules can be multiply. We called it abstract modules. It help users automatic crea-te many modules without any line of code from any exists module which support crea-te abstract modules.<br /> <br /> NukeViet 3 support automatic setup modules, blocks, themes at Admin Control Panel. It&#039;s also allow you to share your modules by packed it into packets.<br /> <br /> NukeViet 3 support multi languages in 2 types. Multi interface languages and multi database langguages. Had features support web master to build new languages. Many advance features still developing. Let use it, distribute it and feel about opensource.<br /> <br /> At last, NukeViet 3 is a thanksgiving gift from VINADES.,JSC to community for all of your supports. And we hoping we going to be a biggest opensource CMS not only in VietNam, but also in the world. :).<br /> <br /> If you had any feedbacks and ideas for NukeViet 3 close beta. Feel free to send email to admin@nukeviet.vn. All are welcome<br /> <br /> Best regard.</p>', '', 0, '4', '', 0, 1, 1, 1277266815, 1277266815, 1), 
(2, 'NukeViet&#039;s versioning schemes', 'NukeViet-s-versioning-schemes', '', '', 0, '', '<p> NukeViet using 2 versioning schemes:<br /> <br /> I. By numbers (technical purposes):<br /> Structure for numbers is:<br /> major.minor.revision<br /> <br /> 1.Major: Major up-date. Probably not backwards compatible with older version.<br /> 2.Minor: Minor change, may introduce new features, but backwards compatibility is mostly retained.<br /> 3.Revision: Minor bug fixes. Packed for testing or pre-release purposes... Closed beta, open beta, RC, Official release.<br /> <br /> II: By names (new version release management)<br /> Main milestones: Closed beta, Open beta, Release candidate, Official.<br /> 1. Closed beta: Limited testing.<br /> characteristics: New features testing. It may not include in official version if doesn&#039;t accord with community. Closed beta&#039;s name can contain unique numbers. Ex: Closed beta 1, closed beta 2,... Features of previous release may not include in it&#039;s next release. Time release is announced by development team. This milestone stop when system haven&#039;t any major changes.<br /> Purposes: Pre-release version to receive feedbacks and ideas from community. Bug fixes for release version.<br /> Release to: Programmers, expert users.<br /> Supports:<br /> &nbsp;&nbsp;&nbsp; Using: None.<br /> &nbsp;&nbsp;&nbsp; Testing: Documents, not include manual.<br /> Upgrade: None.<br /> <br /> 2. Open beta: Public testing.<br /> characteristics: Features testing, contain full features of official version. It&#039;s almost include in official version even if it doesn&#039;t accord with community. This milestone start after closed beta milestone closed and release weekly to fix bugs. Open beta&#039;s name can contain unique numbers. Ex: Open beta 1, open beta 2,... Next release include all features of it&#039;s previous release. Open beta milestone stop when system haven&#039;t any critical issue.<br /> Purposes: Bug fixed which not detect in closed beta.<br /> Release to: All users of nukeviet.vn forum.<br /> Supports:<br /> &nbsp;&nbsp;&nbsp; Using: Limited. Manual and forum supports.<br /> &nbsp;&nbsp;&nbsp; Testing: Full.<br /> Upgrade: None.<br /> <br /> 3. Release Candidate:<br /> characteristics: Most stable version and prepare for official release. Release candidate&#039;s name can contain unique numbers.<br /> Ex: RC 1, RC 2,... by released number.<br /> If detect cretical issue in this milestone. Another Release Candidate version can be release sooner than release time announced by development team.<br /> Purposes: Reduce bugs of using official version.<br /> Release to: All people.<br /> Supports: Full.<br /> Upgrade: Yes.<br /> <br /> 4. Official:<br /> characteristics: 1st stable release of new version. It only using 1 time. Next release using numbers. Release about 2 weeks after Release Candidate milestone stoped.<br /> Purposes: Stop testing and recommend users using new version.</p>', '', 0, '4', '', 0, 2, 1, 1277267054, 1277693688, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_about_config`
--

DROP TABLE IF EXISTS `nv4_en_about_config`;
CREATE TABLE `nv4_en_about_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_about_config`
--

INSERT INTO `nv4_en_about_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_blocks_groups`
--

DROP TABLE IF EXISTS `nv4_en_blocks_groups`;
CREATE TABLE `nv4_en_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` varchar(10)  COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=31  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_blocks_groups`
--

INSERT INTO `nv4_en_blocks_groups` VALUES
(1, 'default', 'news', 'module.block_newscenter.php', 'Breaking news', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 1, 'a:10:{s:6:\"numrow\";i:6;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:12:\"length_title\";i:0;s:15:\"length_hometext\";i:0;s:17:\"length_othertitle\";i:60;s:5:\"width\";i:500;s:6:\"height\";i:0;s:7:\"nocatid\";a:0:{}}'), 
(2, 'default', 'banners', 'global.banners.php', 'Center Banner', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 2, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(3, 'default', 'news', 'global.block_category.php', 'Category', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:25;}'), 
(4, 'default', 'theme', 'global.module_menu.php', 'Module Menu', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 2, ''), 
(5, 'default', 'banners', 'global.banners.php', 'Left Banner', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(6, 'default', 'statistics', 'global.counter.php', 'Statistics', '', 'primary', '[LEFT]', 0, '1', 1, '6', 1, 4, ''), 
(7, 'default', 'about', 'global.about.php', 'About', '', 'border', '[RIGHT]', 0, '1', 1, '6', 1, 1, ''), 
(8, 'default', 'banners', 'global.banners.php', 'Right Banner', '', 'no_title', '[RIGHT]', 0, '1', 1, '6', 1, 2, 'a:1:{s:12:\"idplanbanner\";i:3;}'), 
(9, 'default', 'voting', 'global.voting_random.php', 'Voting', '', 'primary', '[RIGHT]', 0, '1', 1, '6', 1, 3, ''), 
(10, 'default', 'news', 'global.block_tophits.php', 'Top Hits', '', 'primary', '[RIGHT]', 0, '1', 1, '6', 1, 4, 'a:6:{s:10:\"number_day\";i:3650;s:6:\"numrow\";i:10;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:7:\"nocatid\";a:2:{i:0;i:10;i:1;i:11;}}'), 
(11, 'default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:47:\"/bitcoin/index.php?language=en&amp;nv=siteterms\";}'), 
(12, 'default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 2, ''), 
(13, 'default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[QR_CODE]', 0, '1', 1, '6', 1, 1, 'a:3:{s:5:\"level\";s:1:\"M\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(14, 'default', 'statistics', 'global.counter_button.php', 'Online button', '', 'no_title', '[QR_CODE]', 0, '1', 1, '6', 1, 2, ''), 
(15, 'default', 'users', 'global.user_button.php', 'Member login', '', 'no_title', '[PERSONALAREA]', 0, '1', 1, '6', 1, 1, ''), 
(16, 'default', 'theme', 'global.company_info.php', 'Managing company', '', 'simple', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:\"company_name\";s:51:\"Vietnam Open Source Development Joint Stock Company\";s:15:\"company_address\";s:86:\"Room 2004 – CT2 Nang Huong building, 583 Nguyen Trai street, Ha Dong, Hanoi, Vietnam\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.984516000000013;s:20:\"company_mapcenterlng\";d:105.795475;s:14:\"company_maplat\";d:20.984515999999999;s:14:\"company_maplng\";d:105.79547500000001;s:15:\"company_mapzoom\";i:17;s:13:\"company_phone\";s:56:\"+84-4-85872007[+84485872007]|+84-904762534[+84904762534]\";s:11:\"company_fax\";s:14:\"+84-4-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(17, 'default', 'menu', 'global.bootstrap.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(18, 'default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[CONTACT_DEFAULT]', 0, '1', 1, '6', 1, 1, ''), 
(19, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 1, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(20, 'default', 'theme', 'global.menu_footer.php', 'Main categories', '', 'simple', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:8:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";}}'), 
(21, 'default', 'freecontent', 'global.free_content.php', 'Introduction', '', 'no_title', '[FEATURED_PRODUCT]', 0, '1', 1, '6', 1, 1, 'a:2:{s:7:\"blockid\";i:1;s:7:\"numrows\";i:2;}'), 
(22, 'mobile_default', 'menu', 'global.metismenu.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(23, 'mobile_default', 'users', 'global.user_button.php', 'Sign In', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 2, ''), 
(24, 'mobile_default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 1, ''), 
(25, 'mobile_default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 2, ''), 
(26, 'mobile_default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 3, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(27, 'mobile_default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 4, 'a:3:{s:5:\"level\";s:1:\"L\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(28, 'mobile_default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:47:\"/bitcoin/index.php?language=en&amp;nv=siteterms\";}'), 
(29, 'mobile_default', 'theme', 'global.menu_footer.php', 'Main categories', '', 'primary', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:9:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";i:8;s:9:\"siteterms\";}}'), 
(30, 'mobile_default', 'theme', 'global.company_info.php', 'Managing company', '', 'primary', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:\"company_name\";s:51:\"Vietnam Open Source Development Joint Stock Company\";s:15:\"company_address\";s:86:\"Room 2004 – CT2 Nang Huong building, 583 Nguyen Trai street, Ha Dong, Hanoi, Vietnam\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.984516000000013;s:20:\"company_mapcenterlng\";d:105.795475;s:14:\"company_maplat\";d:20.984515999999999;s:14:\"company_maplng\";d:105.79547500000001;s:15:\"company_mapzoom\";i:17;s:13:\"company_phone\";s:56:\"+84-4-85872007[+84485872007]|+84-904762534[+84904762534]\";s:11:\"company_fax\";s:14:\"+84-4-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_blocks_weight`
--

DROP TABLE IF EXISTS `nv4_en_blocks_weight`;
CREATE TABLE `nv4_en_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_blocks_weight`
--

INSERT INTO `nv4_en_blocks_weight` VALUES
(16, 1, 1), 
(16, 37, 1), 
(16, 38, 1), 
(16, 39, 1), 
(16, 40, 1), 
(16, 46, 1), 
(16, 47, 1), 
(16, 48, 1), 
(16, 49, 1), 
(16, 56, 1), 
(16, 59, 1), 
(16, 4, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 8, 1), 
(16, 9, 1), 
(16, 10, 1), 
(16, 11, 1), 
(16, 12, 1), 
(16, 50, 1), 
(16, 58, 1), 
(16, 53, 1), 
(16, 54, 1), 
(16, 30, 1), 
(16, 31, 1), 
(16, 32, 1), 
(16, 33, 1), 
(16, 34, 1), 
(16, 35, 1), 
(16, 36, 1), 
(16, 18, 1), 
(16, 19, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 22, 1), 
(16, 23, 1), 
(16, 24, 1), 
(16, 25, 1), 
(16, 26, 1), 
(16, 27, 1), 
(16, 28, 1), 
(16, 57, 1), 
(18, 1, 1), 
(18, 37, 1), 
(18, 38, 1), 
(18, 39, 1), 
(18, 40, 1), 
(18, 46, 1), 
(18, 47, 1), 
(18, 48, 1), 
(18, 49, 1), 
(18, 56, 1), 
(18, 59, 1), 
(18, 4, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 8, 1), 
(18, 9, 1), 
(18, 10, 1), 
(18, 11, 1), 
(18, 12, 1), 
(18, 50, 1), 
(18, 58, 1), 
(18, 53, 1), 
(18, 54, 1), 
(18, 30, 1), 
(18, 31, 1), 
(18, 32, 1), 
(18, 33, 1), 
(18, 34, 1), 
(18, 35, 1), 
(18, 36, 1), 
(18, 18, 1), 
(18, 19, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 22, 1), 
(18, 23, 1), 
(18, 24, 1), 
(18, 25, 1), 
(18, 26, 1), 
(18, 27, 1), 
(18, 28, 1), 
(18, 57, 1), 
(21, 1, 1), 
(21, 37, 1), 
(21, 38, 1), 
(21, 39, 1), 
(21, 40, 1), 
(21, 46, 1), 
(21, 47, 1), 
(21, 48, 1), 
(21, 49, 1), 
(21, 56, 1), 
(21, 59, 1), 
(21, 4, 1), 
(21, 5, 1), 
(21, 6, 1), 
(21, 7, 1), 
(21, 8, 1), 
(21, 9, 1), 
(21, 10, 1), 
(21, 11, 1), 
(21, 12, 1), 
(21, 50, 1), 
(21, 58, 1), 
(21, 53, 1), 
(21, 54, 1), 
(21, 30, 1), 
(21, 31, 1), 
(21, 32, 1), 
(21, 33, 1), 
(21, 34, 1), 
(21, 35, 1), 
(21, 36, 1), 
(21, 18, 1), 
(21, 19, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 22, 1), 
(21, 23, 1), 
(21, 24, 1), 
(21, 25, 1), 
(21, 26, 1), 
(21, 27, 1), 
(21, 28, 1), 
(21, 57, 1), 
(11, 1, 1), 
(11, 37, 1), 
(11, 38, 1), 
(11, 39, 1), 
(11, 40, 1), 
(11, 46, 1), 
(11, 47, 1), 
(11, 48, 1), 
(11, 49, 1), 
(11, 56, 1), 
(11, 59, 1), 
(11, 4, 1), 
(11, 5, 1), 
(11, 6, 1), 
(11, 7, 1), 
(11, 8, 1), 
(11, 9, 1), 
(11, 10, 1), 
(11, 11, 1), 
(11, 12, 1), 
(11, 50, 1), 
(11, 58, 1), 
(11, 53, 1), 
(11, 54, 1), 
(11, 30, 1), 
(11, 31, 1), 
(11, 32, 1), 
(11, 33, 1), 
(11, 34, 1), 
(11, 35, 1), 
(11, 36, 1), 
(11, 18, 1), 
(11, 19, 1), 
(11, 20, 1), 
(11, 21, 1), 
(11, 22, 1), 
(11, 23, 1), 
(11, 24, 1), 
(11, 25, 1), 
(11, 26, 1), 
(11, 27, 1), 
(11, 28, 1), 
(11, 57, 1), 
(12, 1, 2), 
(12, 37, 2), 
(12, 38, 2), 
(12, 39, 2), 
(12, 40, 2), 
(12, 46, 2), 
(12, 47, 2), 
(12, 48, 2), 
(12, 49, 2), 
(12, 56, 2), 
(12, 59, 2), 
(12, 4, 2), 
(12, 5, 2), 
(12, 6, 2), 
(12, 7, 2), 
(12, 8, 2), 
(12, 9, 2), 
(12, 10, 2), 
(12, 11, 2), 
(12, 12, 2), 
(12, 50, 2), 
(12, 58, 2), 
(12, 53, 2), 
(12, 54, 2), 
(12, 30, 2), 
(12, 31, 2), 
(12, 32, 2), 
(12, 33, 2), 
(12, 34, 2), 
(12, 35, 2), 
(12, 36, 2), 
(12, 18, 2), 
(12, 19, 2), 
(12, 20, 2), 
(12, 21, 2), 
(12, 22, 2), 
(12, 23, 2), 
(12, 24, 2), 
(12, 25, 2), 
(12, 26, 2), 
(12, 27, 2), 
(12, 28, 2), 
(12, 57, 2), 
(3, 4, 1), 
(3, 5, 1), 
(3, 6, 1), 
(3, 7, 1), 
(3, 8, 1), 
(3, 9, 1), 
(3, 10, 1), 
(3, 11, 1), 
(3, 12, 1), 
(4, 18, 1), 
(4, 19, 1), 
(4, 20, 1), 
(4, 21, 1), 
(4, 22, 1), 
(4, 23, 1), 
(4, 24, 1), 
(4, 25, 1), 
(4, 26, 1), 
(4, 27, 1), 
(4, 30, 1), 
(4, 31, 1), 
(4, 32, 1), 
(4, 33, 1), 
(4, 34, 1), 
(4, 35, 1), 
(4, 36, 1), 
(5, 1, 1), 
(5, 37, 1), 
(5, 38, 1), 
(5, 39, 1), 
(5, 40, 1), 
(5, 46, 1), 
(5, 47, 1), 
(5, 48, 1), 
(5, 49, 1), 
(5, 56, 1), 
(5, 59, 1), 
(5, 4, 2), 
(5, 5, 2), 
(5, 6, 2), 
(5, 7, 2), 
(5, 8, 2), 
(5, 9, 2), 
(5, 10, 2), 
(5, 11, 2), 
(5, 12, 2), 
(5, 50, 1), 
(5, 58, 1), 
(5, 53, 1), 
(5, 54, 1), 
(5, 30, 2), 
(5, 31, 2), 
(5, 32, 2), 
(5, 33, 2), 
(5, 34, 2), 
(5, 35, 2), 
(5, 36, 2), 
(5, 18, 2), 
(5, 19, 2), 
(5, 20, 2), 
(5, 21, 2), 
(5, 22, 2), 
(5, 23, 2), 
(5, 24, 2), 
(5, 25, 2), 
(5, 26, 2), 
(5, 27, 2), 
(5, 28, 1), 
(5, 57, 1), 
(6, 1, 2), 
(6, 37, 2), 
(6, 38, 2), 
(6, 39, 2), 
(6, 40, 2), 
(6, 46, 2), 
(6, 47, 2), 
(6, 48, 2), 
(6, 49, 2), 
(6, 56, 2), 
(6, 59, 2), 
(6, 4, 3), 
(6, 5, 3), 
(6, 6, 3), 
(6, 7, 3), 
(6, 8, 3), 
(6, 9, 3), 
(6, 10, 3), 
(6, 11, 3), 
(6, 12, 3), 
(6, 50, 2), 
(6, 58, 2), 
(6, 53, 2), 
(6, 54, 2), 
(6, 30, 3), 
(6, 31, 3), 
(6, 32, 3), 
(6, 33, 3), 
(6, 34, 3), 
(6, 35, 3), 
(6, 36, 3), 
(6, 18, 3), 
(6, 19, 3), 
(6, 20, 3), 
(6, 21, 3), 
(6, 22, 3), 
(6, 23, 3), 
(6, 24, 3), 
(6, 25, 3), 
(6, 26, 3), 
(6, 27, 3), 
(6, 28, 2), 
(6, 57, 2), 
(20, 1, 1), 
(20, 37, 1), 
(20, 38, 1), 
(20, 39, 1), 
(20, 40, 1), 
(20, 46, 1), 
(20, 47, 1), 
(20, 48, 1), 
(20, 49, 1), 
(20, 56, 1), 
(20, 59, 1), 
(20, 4, 1), 
(20, 5, 1), 
(20, 6, 1), 
(20, 7, 1), 
(20, 8, 1), 
(20, 9, 1), 
(20, 10, 1), 
(20, 11, 1), 
(20, 12, 1), 
(20, 50, 1), 
(20, 58, 1), 
(20, 53, 1), 
(20, 54, 1), 
(20, 30, 1), 
(20, 31, 1), 
(20, 32, 1), 
(20, 33, 1), 
(20, 34, 1), 
(20, 35, 1), 
(20, 36, 1), 
(20, 18, 1), 
(20, 19, 1), 
(20, 20, 1), 
(20, 21, 1), 
(20, 22, 1), 
(20, 23, 1), 
(20, 24, 1), 
(20, 25, 1), 
(20, 26, 1), 
(20, 27, 1), 
(20, 28, 1), 
(20, 57, 1), 
(17, 1, 1), 
(17, 37, 1), 
(17, 38, 1), 
(17, 39, 1), 
(17, 40, 1), 
(17, 46, 1), 
(17, 47, 1), 
(17, 48, 1), 
(17, 49, 1), 
(17, 56, 1), 
(17, 59, 1), 
(17, 4, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 8, 1), 
(17, 9, 1), 
(17, 10, 1), 
(17, 11, 1), 
(17, 12, 1), 
(17, 50, 1), 
(17, 58, 1), 
(17, 53, 1), 
(17, 54, 1), 
(17, 30, 1), 
(17, 31, 1), 
(17, 32, 1), 
(17, 33, 1), 
(17, 34, 1), 
(17, 35, 1), 
(17, 36, 1), 
(17, 18, 1), 
(17, 19, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 22, 1), 
(17, 23, 1), 
(17, 24, 1), 
(17, 25, 1), 
(17, 26, 1), 
(17, 27, 1), 
(17, 28, 1), 
(17, 57, 1), 
(15, 1, 1), 
(15, 37, 1), 
(15, 38, 1), 
(15, 39, 1), 
(15, 40, 1), 
(15, 46, 1), 
(15, 47, 1), 
(15, 48, 1), 
(15, 49, 1), 
(15, 56, 1), 
(15, 59, 1), 
(15, 4, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 8, 1), 
(15, 9, 1), 
(15, 10, 1), 
(15, 11, 1), 
(15, 12, 1), 
(15, 50, 1), 
(15, 58, 1), 
(15, 53, 1), 
(15, 54, 1), 
(15, 30, 1), 
(15, 31, 1), 
(15, 32, 1), 
(15, 33, 1), 
(15, 34, 1), 
(15, 35, 1), 
(15, 36, 1), 
(15, 18, 1), 
(15, 19, 1), 
(15, 20, 1), 
(15, 21, 1), 
(15, 22, 1), 
(15, 23, 1), 
(15, 24, 1), 
(15, 25, 1), 
(15, 26, 1), 
(15, 27, 1), 
(15, 28, 1), 
(15, 57, 1), 
(13, 1, 1), 
(13, 37, 1), 
(13, 38, 1), 
(13, 39, 1), 
(13, 40, 1), 
(13, 46, 1), 
(13, 47, 1), 
(13, 48, 1), 
(13, 49, 1), 
(13, 56, 1), 
(13, 59, 1), 
(13, 4, 1), 
(13, 5, 1), 
(13, 6, 1), 
(13, 7, 1), 
(13, 8, 1), 
(13, 9, 1), 
(13, 10, 1), 
(13, 11, 1), 
(13, 12, 1), 
(13, 50, 1), 
(13, 58, 1), 
(13, 53, 1), 
(13, 54, 1), 
(13, 30, 1), 
(13, 31, 1), 
(13, 32, 1), 
(13, 33, 1), 
(13, 34, 1), 
(13, 35, 1), 
(13, 36, 1), 
(13, 18, 1), 
(13, 19, 1), 
(13, 20, 1), 
(13, 21, 1), 
(13, 22, 1), 
(13, 23, 1), 
(13, 24, 1), 
(13, 25, 1), 
(13, 26, 1), 
(13, 27, 1), 
(13, 28, 1), 
(13, 57, 1), 
(14, 1, 2), 
(14, 37, 2), 
(14, 38, 2), 
(14, 39, 2), 
(14, 40, 2), 
(14, 46, 2), 
(14, 47, 2), 
(14, 48, 2), 
(14, 49, 2), 
(14, 56, 2), 
(14, 59, 2), 
(14, 4, 2), 
(14, 5, 2), 
(14, 6, 2), 
(14, 7, 2), 
(14, 8, 2), 
(14, 9, 2), 
(14, 10, 2), 
(14, 11, 2), 
(14, 12, 2), 
(14, 50, 2), 
(14, 58, 2), 
(14, 53, 2), 
(14, 54, 2), 
(14, 30, 2), 
(14, 31, 2), 
(14, 32, 2), 
(14, 33, 2), 
(14, 34, 2), 
(14, 35, 2), 
(14, 36, 2), 
(14, 18, 2), 
(14, 19, 2), 
(14, 20, 2), 
(14, 21, 2), 
(14, 22, 2), 
(14, 23, 2), 
(14, 24, 2), 
(14, 25, 2), 
(14, 26, 2), 
(14, 27, 2), 
(14, 28, 2), 
(14, 57, 2), 
(7, 1, 1), 
(7, 37, 1), 
(7, 38, 1), 
(7, 39, 1), 
(7, 40, 1), 
(7, 46, 1), 
(7, 47, 1), 
(7, 48, 1), 
(7, 49, 1), 
(7, 56, 1), 
(7, 59, 1), 
(7, 4, 1), 
(7, 5, 1), 
(7, 6, 1), 
(7, 7, 1), 
(7, 8, 1), 
(7, 9, 1), 
(7, 10, 1), 
(7, 11, 1), 
(7, 12, 1), 
(7, 50, 1), 
(7, 58, 1), 
(7, 53, 1), 
(7, 54, 1), 
(7, 30, 1), 
(7, 31, 1), 
(7, 32, 1), 
(7, 33, 1), 
(7, 34, 1), 
(7, 35, 1), 
(7, 36, 1), 
(7, 18, 1), 
(7, 19, 1), 
(7, 20, 1), 
(7, 21, 1), 
(7, 22, 1), 
(7, 23, 1), 
(7, 24, 1), 
(7, 25, 1), 
(7, 26, 1), 
(7, 27, 1), 
(7, 28, 1), 
(7, 57, 1), 
(8, 1, 2), 
(8, 37, 2), 
(8, 38, 2), 
(8, 39, 2), 
(8, 40, 2), 
(8, 46, 2), 
(8, 47, 2), 
(8, 48, 2), 
(8, 49, 2), 
(8, 56, 2), 
(8, 59, 2), 
(8, 4, 2), 
(8, 5, 2), 
(8, 6, 2), 
(8, 7, 2), 
(8, 8, 2), 
(8, 9, 2), 
(8, 10, 2), 
(8, 11, 2), 
(8, 12, 2), 
(8, 50, 2), 
(8, 58, 2), 
(8, 53, 2), 
(8, 54, 2), 
(8, 30, 2), 
(8, 31, 2), 
(8, 32, 2), 
(8, 33, 2), 
(8, 34, 2), 
(8, 35, 2), 
(8, 36, 2), 
(8, 18, 2), 
(8, 19, 2), 
(8, 20, 2), 
(8, 21, 2), 
(8, 22, 2), 
(8, 23, 2), 
(8, 24, 2), 
(8, 25, 2), 
(8, 26, 2), 
(8, 27, 2), 
(8, 28, 2), 
(8, 57, 2), 
(9, 1, 3), 
(9, 37, 3), 
(9, 38, 3), 
(9, 39, 3), 
(9, 40, 3), 
(9, 46, 3), 
(9, 47, 3), 
(9, 48, 3), 
(9, 49, 3), 
(9, 56, 3), 
(9, 59, 3), 
(9, 4, 3), 
(9, 5, 3), 
(9, 6, 3), 
(9, 7, 3), 
(9, 8, 3), 
(9, 9, 3), 
(9, 10, 3), 
(9, 11, 3), 
(9, 12, 3), 
(9, 50, 3), 
(9, 58, 3), 
(9, 53, 3), 
(9, 54, 3), 
(9, 30, 3), 
(9, 31, 3), 
(9, 32, 3), 
(9, 33, 3), 
(9, 34, 3), 
(9, 35, 3), 
(9, 36, 3), 
(9, 18, 3), 
(9, 19, 3), 
(9, 20, 3), 
(9, 21, 3), 
(9, 22, 3), 
(9, 23, 3), 
(9, 24, 3), 
(9, 25, 3), 
(9, 26, 3), 
(9, 27, 3), 
(9, 28, 3), 
(9, 57, 3), 
(10, 1, 4), 
(10, 37, 4), 
(10, 38, 4), 
(10, 39, 4), 
(10, 40, 4), 
(10, 46, 4), 
(10, 47, 4), 
(10, 48, 4), 
(10, 49, 4), 
(10, 56, 4), 
(10, 59, 4), 
(10, 4, 4), 
(10, 5, 4), 
(10, 6, 4), 
(10, 7, 4), 
(10, 8, 4), 
(10, 9, 4), 
(10, 10, 4), 
(10, 11, 4), 
(10, 12, 4), 
(10, 50, 4), 
(10, 58, 4), 
(10, 53, 4), 
(10, 54, 4), 
(10, 30, 4), 
(10, 31, 4), 
(10, 32, 4), 
(10, 33, 4), 
(10, 34, 4), 
(10, 35, 4), 
(10, 36, 4), 
(10, 18, 4), 
(10, 19, 4), 
(10, 20, 4), 
(10, 21, 4), 
(10, 22, 4), 
(10, 23, 4), 
(10, 24, 4), 
(10, 25, 4), 
(10, 26, 4), 
(10, 27, 4), 
(10, 28, 4), 
(10, 57, 4), 
(19, 1, 1), 
(19, 37, 1), 
(19, 38, 1), 
(19, 39, 1), 
(19, 40, 1), 
(19, 46, 1), 
(19, 47, 1), 
(19, 48, 1), 
(19, 49, 1), 
(19, 56, 1), 
(19, 59, 1), 
(19, 4, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 8, 1), 
(19, 9, 1), 
(19, 10, 1), 
(19, 11, 1), 
(19, 12, 1), 
(19, 50, 1), 
(19, 58, 1), 
(19, 53, 1), 
(19, 54, 1), 
(19, 30, 1), 
(19, 31, 1), 
(19, 32, 1), 
(19, 33, 1), 
(19, 34, 1), 
(19, 35, 1), 
(19, 36, 1), 
(19, 18, 1), 
(19, 19, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 22, 1), 
(19, 23, 1), 
(19, 24, 1), 
(19, 25, 1), 
(19, 26, 1), 
(19, 27, 1), 
(19, 28, 1), 
(19, 57, 1), 
(1, 4, 1), 
(2, 4, 2), 
(30, 1, 1), 
(30, 37, 1), 
(30, 38, 1), 
(30, 39, 1), 
(30, 40, 1), 
(30, 46, 1), 
(30, 47, 1), 
(30, 48, 1), 
(30, 49, 1), 
(30, 56, 1), 
(30, 59, 1), 
(30, 4, 1), 
(30, 5, 1), 
(30, 6, 1), 
(30, 7, 1), 
(30, 8, 1), 
(30, 9, 1), 
(30, 10, 1), 
(30, 11, 1), 
(30, 12, 1), 
(30, 50, 1), 
(30, 58, 1), 
(30, 53, 1), 
(30, 54, 1), 
(30, 30, 1), 
(30, 31, 1), 
(30, 32, 1), 
(30, 33, 1), 
(30, 34, 1), 
(30, 35, 1), 
(30, 36, 1), 
(30, 18, 1), 
(30, 19, 1), 
(30, 20, 1), 
(30, 21, 1), 
(30, 22, 1), 
(30, 23, 1), 
(30, 24, 1), 
(30, 25, 1), 
(30, 26, 1), 
(30, 27, 1), 
(30, 28, 1), 
(30, 57, 1), 
(28, 1, 1), 
(28, 37, 1), 
(28, 38, 1), 
(28, 39, 1), 
(28, 40, 1), 
(28, 46, 1), 
(28, 47, 1), 
(28, 48, 1), 
(28, 49, 1), 
(28, 56, 1), 
(28, 59, 1), 
(28, 4, 1), 
(28, 5, 1), 
(28, 6, 1), 
(28, 7, 1), 
(28, 8, 1), 
(28, 9, 1), 
(28, 10, 1), 
(28, 11, 1), 
(28, 12, 1), 
(28, 50, 1), 
(28, 58, 1), 
(28, 53, 1), 
(28, 54, 1), 
(28, 30, 1), 
(28, 31, 1), 
(28, 32, 1), 
(28, 33, 1), 
(28, 34, 1), 
(28, 35, 1), 
(28, 36, 1), 
(28, 18, 1), 
(28, 19, 1), 
(28, 20, 1), 
(28, 21, 1), 
(28, 22, 1), 
(28, 23, 1), 
(28, 24, 1), 
(28, 25, 1), 
(28, 26, 1), 
(28, 27, 1), 
(28, 28, 1), 
(28, 57, 1), 
(29, 1, 1), 
(29, 37, 1), 
(29, 38, 1), 
(29, 39, 1), 
(29, 40, 1), 
(29, 46, 1), 
(29, 47, 1), 
(29, 48, 1), 
(29, 49, 1), 
(29, 56, 1), 
(29, 59, 1), 
(29, 4, 1), 
(29, 5, 1), 
(29, 6, 1), 
(29, 7, 1), 
(29, 8, 1), 
(29, 9, 1), 
(29, 10, 1), 
(29, 11, 1), 
(29, 12, 1), 
(29, 50, 1), 
(29, 58, 1), 
(29, 53, 1), 
(29, 54, 1), 
(29, 30, 1), 
(29, 31, 1), 
(29, 32, 1), 
(29, 33, 1), 
(29, 34, 1), 
(29, 35, 1), 
(29, 36, 1), 
(29, 18, 1), 
(29, 19, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 22, 1), 
(29, 23, 1), 
(29, 24, 1), 
(29, 25, 1), 
(29, 26, 1), 
(29, 27, 1), 
(29, 28, 1), 
(29, 57, 1), 
(22, 1, 1), 
(22, 37, 1), 
(22, 38, 1), 
(22, 39, 1), 
(22, 40, 1), 
(22, 46, 1), 
(22, 47, 1), 
(22, 48, 1), 
(22, 49, 1), 
(22, 56, 1), 
(22, 59, 1), 
(22, 4, 1), 
(22, 5, 1), 
(22, 6, 1), 
(22, 7, 1), 
(22, 8, 1), 
(22, 9, 1), 
(22, 10, 1), 
(22, 11, 1), 
(22, 12, 1), 
(22, 50, 1), 
(22, 58, 1), 
(22, 53, 1), 
(22, 54, 1), 
(22, 30, 1), 
(22, 31, 1), 
(22, 32, 1), 
(22, 33, 1), 
(22, 34, 1), 
(22, 35, 1), 
(22, 36, 1), 
(22, 18, 1), 
(22, 19, 1), 
(22, 20, 1), 
(22, 21, 1), 
(22, 22, 1), 
(22, 23, 1), 
(22, 24, 1), 
(22, 25, 1), 
(22, 26, 1), 
(22, 27, 1), 
(22, 28, 1), 
(22, 57, 1), 
(23, 1, 2), 
(23, 37, 2), 
(23, 38, 2), 
(23, 39, 2), 
(23, 40, 2), 
(23, 46, 2), 
(23, 47, 2), 
(23, 48, 2), 
(23, 49, 2), 
(23, 56, 2), 
(23, 59, 2), 
(23, 4, 2), 
(23, 5, 2), 
(23, 6, 2), 
(23, 7, 2), 
(23, 8, 2), 
(23, 9, 2), 
(23, 10, 2), 
(23, 11, 2), 
(23, 12, 2), 
(23, 50, 2), 
(23, 58, 2), 
(23, 53, 2), 
(23, 54, 2), 
(23, 30, 2), 
(23, 31, 2), 
(23, 32, 2), 
(23, 33, 2), 
(23, 34, 2), 
(23, 35, 2), 
(23, 36, 2), 
(23, 18, 2), 
(23, 19, 2), 
(23, 20, 2), 
(23, 21, 2), 
(23, 22, 2), 
(23, 23, 2), 
(23, 24, 2), 
(23, 25, 2), 
(23, 26, 2), 
(23, 27, 2), 
(23, 28, 2), 
(23, 57, 2), 
(24, 1, 1), 
(24, 37, 1), 
(24, 38, 1), 
(24, 39, 1), 
(24, 40, 1), 
(24, 46, 1), 
(24, 47, 1), 
(24, 48, 1), 
(24, 49, 1), 
(24, 56, 1), 
(24, 59, 1), 
(24, 4, 1), 
(24, 5, 1), 
(24, 6, 1), 
(24, 7, 1), 
(24, 8, 1), 
(24, 9, 1), 
(24, 10, 1), 
(24, 11, 1), 
(24, 12, 1), 
(24, 50, 1), 
(24, 58, 1), 
(24, 53, 1), 
(24, 54, 1), 
(24, 30, 1), 
(24, 31, 1), 
(24, 32, 1), 
(24, 33, 1), 
(24, 34, 1), 
(24, 35, 1), 
(24, 36, 1), 
(24, 18, 1), 
(24, 19, 1), 
(24, 20, 1), 
(24, 21, 1), 
(24, 22, 1), 
(24, 23, 1), 
(24, 24, 1), 
(24, 25, 1), 
(24, 26, 1), 
(24, 27, 1), 
(24, 28, 1), 
(24, 57, 1), 
(25, 1, 2), 
(25, 37, 2), 
(25, 38, 2), 
(25, 39, 2), 
(25, 40, 2), 
(25, 46, 2), 
(25, 47, 2), 
(25, 48, 2), 
(25, 49, 2), 
(25, 56, 2), 
(25, 59, 2), 
(25, 4, 2), 
(25, 5, 2), 
(25, 6, 2), 
(25, 7, 2), 
(25, 8, 2), 
(25, 9, 2), 
(25, 10, 2), 
(25, 11, 2), 
(25, 12, 2), 
(25, 50, 2), 
(25, 58, 2), 
(25, 53, 2), 
(25, 54, 2), 
(25, 30, 2), 
(25, 31, 2), 
(25, 32, 2), 
(25, 33, 2), 
(25, 34, 2), 
(25, 35, 2), 
(25, 36, 2), 
(25, 18, 2), 
(25, 19, 2), 
(25, 20, 2), 
(25, 21, 2), 
(25, 22, 2), 
(25, 23, 2), 
(25, 24, 2), 
(25, 25, 2), 
(25, 26, 2), 
(25, 27, 2), 
(25, 28, 2), 
(25, 57, 2), 
(26, 1, 3), 
(26, 37, 3), 
(26, 38, 3), 
(26, 39, 3), 
(26, 40, 3), 
(26, 46, 3), 
(26, 47, 3), 
(26, 48, 3), 
(26, 49, 3), 
(26, 56, 3), 
(26, 59, 3), 
(26, 4, 3), 
(26, 5, 3), 
(26, 6, 3), 
(26, 7, 3), 
(26, 8, 3), 
(26, 9, 3), 
(26, 10, 3), 
(26, 11, 3), 
(26, 12, 3), 
(26, 50, 3), 
(26, 58, 3), 
(26, 53, 3), 
(26, 54, 3), 
(26, 30, 3), 
(26, 31, 3), 
(26, 32, 3), 
(26, 33, 3), 
(26, 34, 3), 
(26, 35, 3), 
(26, 36, 3), 
(26, 18, 3), 
(26, 19, 3), 
(26, 20, 3), 
(26, 21, 3), 
(26, 22, 3), 
(26, 23, 3), 
(26, 24, 3), 
(26, 25, 3), 
(26, 26, 3), 
(26, 27, 3), 
(26, 28, 3), 
(26, 57, 3), 
(27, 1, 4), 
(27, 37, 4), 
(27, 38, 4), 
(27, 39, 4), 
(27, 40, 4), 
(27, 46, 4), 
(27, 47, 4), 
(27, 48, 4), 
(27, 49, 4), 
(27, 56, 4), 
(27, 59, 4), 
(27, 4, 4), 
(27, 5, 4), 
(27, 6, 4), 
(27, 7, 4), 
(27, 8, 4), 
(27, 9, 4), 
(27, 10, 4), 
(27, 11, 4), 
(27, 12, 4), 
(27, 50, 4), 
(27, 58, 4), 
(27, 53, 4), 
(27, 54, 4), 
(27, 30, 4), 
(27, 31, 4), 
(27, 32, 4), 
(27, 33, 4), 
(27, 34, 4), 
(27, 35, 4), 
(27, 36, 4), 
(27, 18, 4), 
(27, 19, 4), 
(27, 20, 4), 
(27, 21, 4), 
(27, 22, 4), 
(27, 23, 4), 
(27, 24, 4), 
(27, 25, 4), 
(27, 26, 4), 
(27, 27, 4), 
(27, 28, 4), 
(27, 57, 4);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_comment`
--

DROP TABLE IF EXISTS `nv4_en_comment`;
CREATE TABLE `nv4_en_comment` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_contact_department`
--

DROP TABLE IF EXISTS `nv4_en_contact_department`;
CREATE TABLE `nv4_en_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `cats` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_contact_department`
--

INSERT INTO `nv4_en_contact_department` VALUES
(1, 'Consumer Care Division', 'Consumer-Care', '', '(08) 38.000.000[+84838000000]', '08 38.000.001', 'customer@mysite.com', '', 'Receive requests, suggestions, comments relating to the operations of company', '{\"viber\":\"myViber\",\"skype\":\"mySkype\",\"yahoo\":\"myYahoo\"}', 'Consulting|Complaints|Cooperation', '1/1/1/0;', 1, 1, 1), 
(2, 'Technical Department', 'Technical', '', '(08) 38.000.002[+84838000002]', '08 38.000.003', 'technical@mysite.com', '', 'Resolve technical issues', '{\"viber\":\"myViber2\",\"skype\":\"mySkype2\",\"yahoo\":\"myYahoo2\"}', 'Bug Reports|Recommendations to improve', '1/1/1/0;', 1, 2, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_contact_reply`
--

DROP TABLE IF EXISTS `nv4_en_contact_reply`;
CREATE TABLE `nv4_en_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text  COLLATE utf8mb4_unicode_ci,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_contact_send`
--

DROP TABLE IF EXISTS `nv4_en_contact_send`;
CREATE TABLE `nv4_en_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_phone` varchar(20)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sender_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_freecontent_blocks`
--

DROP TABLE IF EXISTS `nv4_en_freecontent_blocks`;
CREATE TABLE `nv4_en_freecontent_blocks` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_freecontent_blocks`
--

INSERT INTO `nv4_en_freecontent_blocks` VALUES
(1, 'Sản phẩm', 'Sản phẩm của công ty cổ phần phát triển nguồn mở Việt Nam - VINADES.,JSC');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_freecontent_rows`
--

DROP TABLE IF EXISTS `nv4_en_freecontent_rows`;
CREATE TABLE `nv4_en_freecontent_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '_blank|_self|_parent|_top',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `end_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0: In-Active, 1: Active, 2: Expired',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_freecontent_rows`
--

INSERT INTO `nv4_en_freecontent_rows` VALUES
(1, 1, 'Hệ quản trị nội dung NukeViet', '<ul>
	<li>Giải thưởng Nhân tài đất Việt 2011, 10.000+ website đang sử dụng</li>
	<li>Được Bộ GD&amp;ĐT khuyến khích sử dụng trong các cơ sở giáo dục</li>
	<li>Bộ TT&amp;TT quy định ưu tiên sử dụng trong cơ quan nhà nước</li>
</ul>', 'http://vinades.vn/vi/san-pham/nukeviet/', '_blank', 'nukeviet.jpg', 1467731932, 0, 1), 
(2, 1, 'Cổng thông tin doanh nghiệp', '<ul>
	<li>Tích hợp bán hàng trực tuyến</li>
	<li>Tích hợp các nghiệp vụ quản lý (quản lý khách hàng, quản lý nhân sự, quản lý tài liệu)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-doanh-nghiep-NukeViet-portal/', '_blank', 'nukeviet-portal.jpg', 1467731932, 0, 1), 
(3, 1, 'Cổng thông tin Phòng giáo dục, Sở giáo dục', '<ul>
	<li>Tích hợp chung website hàng trăm trường</li>
	<li>Tích hợp các ứng dụng trực tuyến (Tra điểm SMS, Tra cứu văn bằng, Học bạ điện tử ...)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-giao-duc-NukeViet-Edugate/', '_blank', 'nukeviet-edu.jpg', 1467731932, 0, 1), 
(4, 1, 'Tòa soạn báo điện tử chuyên nghiệp', '<ul>
	<li>Bảo mật đa tầng, phân quyền linh hoạt</li>
	<li>Hệ thống bóc tin tự động, đăng bài tự động, cùng nhiều chức năng tiên tiến khác...</li>
</ul>', 'http://vinades.vn/vi/san-pham/Toa-soan-bao-dien-tu/', '_blank', 'nukeviet-toasoan.jpg', 1467731932, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_menu`
--

DROP TABLE IF EXISTS `nv4_en_menu`;
CREATE TABLE `nv4_en_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_menu`
--

INSERT INTO `nv4_en_menu` VALUES
(1, 'Top Menu');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_menu_rows`
--

DROP TABLE IF EXISTS `nv4_en_menu_rows`;
CREATE TABLE `nv4_en_menu_rows` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(5) unsigned NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text  COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `module_name` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `op` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_menu_rows`
--

INSERT INTO `nv4_en_menu_rows` VALUES
(1, 0, 1, 'About', '/bitcoin/index.php?language=en&nv=about', '', '', 1, 1, 0, '', '6', 'about', '', 1, '', 0, 1), 
(2, 0, 1, 'News', '/bitcoin/index.php?language=en&nv=news', '', '', 2, 2, 0, '', '6', 'news', '', 1, '', 0, 1), 
(3, 0, 1, 'Users', '/bitcoin/index.php?language=en&nv=users', '', '', 3, 3, 0, '6,7,8,9,10,11', '6', 'users', '', 1, '', 0, 1), 
(4, 0, 1, 'Voting', '/bitcoin/index.php?language=en&nv=voting', '', '', 4, 10, 0, '', '6', 'voting', '', 1, '', 0, 1), 
(5, 0, 1, 'Contact', '/bitcoin/index.php?language=en&nv=contact', '', '', 5, 11, 0, '', '6', 'contact', '', 1, '', 0, 1), 
(6, 3, 1, 'Login', '/bitcoin/index.php?language=en&nv=users&op=login', '', '', 1, 4, 1, '', '5', 'users', 'login', 1, '', 0, 1), 
(7, 3, 1, 'Register', '/bitcoin/index.php?language=en&nv=users&op=register', '', '', 2, 5, 1, '', '5', 'users', 'register', 1, '', 0, 1), 
(8, 3, 1, 'Password recovery', '/bitcoin/index.php?language=en&nv=users&op=lostpass', '', '', 3, 6, 1, '', '5', 'users', 'lostpass', 1, '', 0, 1), 
(9, 3, 1, 'Account Settings', '/bitcoin/index.php?language=en&nv=users&op=editinfo', '', '', 4, 7, 1, '', '4,7', 'users', 'editinfo', 1, '', 0, 1), 
(10, 3, 1, 'Members list', '/bitcoin/index.php?language=en&nv=users&op=memberlist', '', '', 5, 8, 1, '', '4,7', 'users', 'memberlist', 1, '', 0, 1), 
(11, 3, 1, 'Logout', '/bitcoin/index.php?language=en&nv=users&op=logout', '', '', 6, 9, 1, '', '4,7', 'users', 'logout', 1, '', 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_modfuncs`
--

DROP TABLE IF EXISTS `nv4_en_modfuncs`;
CREATE TABLE `nv4_en_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_custom_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `in_module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=60  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_modfuncs`
--

INSERT INTO `nv4_en_modfuncs` VALUES
(1, 'main', 'main', 'Main', 'about', 1, 0, 1, ''), 
(2, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(3, 'rss', 'rss', 'Rss', 'about', 0, 0, 0, ''), 
(4, 'main', 'main', 'Main', 'news', 1, 0, 1, ''), 
(5, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 2, ''), 
(6, 'topic', 'topic', 'Topic', 'news', 1, 0, 3, ''), 
(7, 'content', 'content', 'Content', 'news', 1, 1, 4, ''), 
(8, 'detail', 'detail', 'Detail', 'news', 1, 0, 5, ''), 
(9, 'tag', 'tag', 'Tag', 'news', 1, 0, 6, ''), 
(10, 'rss', 'rss', 'Rss', 'news', 1, 1, 7, ''), 
(11, 'search', 'search', 'Search', 'news', 1, 1, 8, ''), 
(12, 'groups', 'groups', 'Groups', 'news', 1, 0, 9, ''), 
(13, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(14, 'print', 'print', 'Print', 'news', 0, 0, 0, ''), 
(15, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(16, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(17, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(18, 'main', 'main', 'Main', 'users', 1, 0, 1, ''), 
(19, 'login', 'login', 'Login', 'users', 1, 1, 2, ''), 
(20, 'register', 'register', 'Register', 'users', 1, 1, 3, ''), 
(21, 'lostpass', 'lostpass', 'Password recovery', 'users', 1, 1, 4, ''), 
(22, 'active', 'active', 'Active account', 'users', 1, 0, 5, ''), 
(23, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 6, ''), 
(24, 'editinfo', 'editinfo', 'Account Settings', 'users', 1, 1, 7, ''), 
(25, 'memberlist', 'memberlist', 'Members list', 'users', 1, 1, 8, ''), 
(26, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 9, ''), 
(27, 'logout', 'logout', 'Logout', 'users', 1, 1, 10, ''), 
(28, 'groups', 'groups', 'Group management', 'users', 1, 0, 11, ''), 
(29, 'oauth', 'oauth', 'Oauth', 'users', 0, 0, 0, ''), 
(30, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(31, 'allreferers', 'allreferers', 'By referrers', 'statistics', 1, 1, 2, ''), 
(32, 'allcountries', 'allcountries', 'By countries', 'statistics', 1, 1, 3, ''), 
(33, 'allbrowsers', 'allbrowsers', 'By browsers ', 'statistics', 1, 1, 4, ''), 
(34, 'allos', 'allos', 'By operating system', 'statistics', 1, 1, 5, ''), 
(35, 'allbots', 'allbots', 'By search engines', 'statistics', 1, 1, 6, ''), 
(36, 'referer', 'referer', 'By month', 'statistics', 1, 0, 7, ''), 
(37, 'main', 'main', 'Main', 'banners', 1, 0, 1, ''), 
(38, 'addads', 'addads', 'Addads', 'banners', 1, 0, 2, ''), 
(39, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 3, ''), 
(40, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(41, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(42, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''), 
(43, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(44, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(45, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(46, 'main', 'main', 'main', 'comment', 1, 0, 1, ''), 
(47, 'post', 'post', 'post', 'comment', 1, 0, 2, ''), 
(48, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''), 
(49, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''), 
(50, 'main', 'main', 'Main', 'page', 1, 0, 1, ''), 
(51, 'sitemap', 'sitemap', 'Sitemap', 'page', 0, 0, 0, ''), 
(52, 'rss', 'rss', 'Rss', 'page', 0, 0, 0, ''), 
(53, 'main', 'main', 'Main', 'siteterms', 1, 0, 1, ''), 
(54, 'rss', 'rss', 'Rss', 'siteterms', 1, 0, 2, ''), 
(55, 'sitemap', 'sitemap', 'Sitemap', 'siteterms', 0, 0, 0, ''), 
(56, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''), 
(57, 'main', 'main', 'Main', 'voting', 1, 0, 1, ''), 
(58, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''), 
(59, 'main', 'main', 'Main', 'feeds', 1, 0, 1, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_modthemes`
--

DROP TABLE IF EXISTS `nv4_en_modthemes`;
CREATE TABLE `nv4_en_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_modthemes`
--

INSERT INTO `nv4_en_modthemes` VALUES
(0, 'left-main-right', 'default'), 
(0, 'main', 'mobile_default'), 
(1, 'left-main-right', 'default'), 
(1, 'main', 'mobile_default'), 
(4, 'left-main-right', 'default'), 
(4, 'main', 'mobile_default'), 
(5, 'left-main-right', 'default'), 
(5, 'main', 'mobile_default'), 
(6, 'left-main-right', 'default'), 
(6, 'main', 'mobile_default'), 
(7, 'left-main-right', 'default'), 
(7, 'main', 'mobile_default'), 
(8, 'left-main-right', 'default'), 
(8, 'main', 'mobile_default'), 
(9, 'left-main-right', 'default'), 
(9, 'main', 'mobile_default'), 
(10, 'left-main-right', 'default'), 
(11, 'left-main-right', 'default'), 
(11, 'main', 'mobile_default'), 
(12, 'left-main-right', 'default'), 
(12, 'main', 'mobile_default'), 
(18, 'left-main-right', 'default'), 
(18, 'main', 'mobile_default'), 
(19, 'left-main-right', 'default'), 
(19, 'main', 'mobile_default'), 
(20, 'left-main-right', 'default'), 
(20, 'main', 'mobile_default'), 
(21, 'left-main-right', 'default'), 
(21, 'main', 'mobile_default'), 
(22, 'left-main-right', 'default'), 
(22, 'main', 'mobile_default'), 
(23, 'left-main-right', 'default'), 
(23, 'main', 'mobile_default'), 
(24, 'left-main', 'default'), 
(24, 'main', 'mobile_default'), 
(25, 'left-main-right', 'default'), 
(25, 'main', 'mobile_default'), 
(26, 'left-main-right', 'default'), 
(27, 'left-main-right', 'default'), 
(27, 'main', 'mobile_default'), 
(28, 'left-main', 'default'), 
(28, 'main', 'mobile_default'), 
(30, 'left-main', 'default'), 
(30, 'main', 'mobile_default'), 
(31, 'left-main', 'default'), 
(31, 'main', 'mobile_default'), 
(32, 'left-main', 'default'), 
(32, 'main', 'mobile_default'), 
(33, 'left-main', 'default'), 
(33, 'main', 'mobile_default'), 
(34, 'left-main', 'default'), 
(34, 'main', 'mobile_default'), 
(35, 'left-main', 'default'), 
(35, 'main', 'mobile_default'), 
(36, 'left-main', 'default'), 
(36, 'main', 'mobile_default'), 
(37, 'left-main-right', 'default'), 
(37, 'main', 'mobile_default'), 
(38, 'left-main-right', 'default'), 
(38, 'main', 'mobile_default'), 
(39, 'left-main-right', 'default'), 
(39, 'main', 'mobile_default'), 
(40, 'left-main-right', 'default'), 
(40, 'main', 'mobile_default'), 
(46, 'left-main-right', 'default'), 
(46, 'main', 'mobile_default'), 
(47, 'left-main-right', 'default'), 
(47, 'main', 'mobile_default'), 
(48, 'left-main-right', 'default'), 
(48, 'main', 'mobile_default'), 
(49, 'left-main-right', 'default'), 
(49, 'main', 'mobile_default'), 
(50, 'left-main', 'default'), 
(50, 'main', 'mobile_default'), 
(53, 'left-main-right', 'default'), 
(53, 'main', 'mobile_default'), 
(54, 'left-main-right', 'default'), 
(54, 'main', 'mobile_default'), 
(56, 'left-main', 'default'), 
(56, 'main', 'mobile_default'), 
(57, 'left-main', 'default'), 
(57, 'main', 'mobile_default'), 
(58, 'left-main-right', 'default'), 
(58, 'main', 'mobile_default'), 
(59, 'left-main-right', 'default'), 
(59, 'main', 'mobile_default');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_modules`
--

DROP TABLE IF EXISTS `nv4_en_modules`;
CREATE TABLE `nv4_en_modules` (
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_file` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_data` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_upload` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `custom_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_title` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `mobile` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_modules`
--

INSERT INTO `nv4_en_modules` VALUES
('about', 'page', 'about', 'about', 'About', '', 1467731932, 1, 1, '', '', '', '', '6', 1, 1, '', 1, 0), 
('news', 'news', 'news', 'news', 'News', '', 1467731932, 1, 1, '', '', '', '', '6', 2, 1, '', 1, 0), 
('users', 'users', 'users', 'users', 'Users', 'Users', 1467731932, 1, 1, '', '', '', '', '6', 3, 1, '', 0, 0), 
('contact', 'contact', 'contact', 'contact', 'Contact', '', 1467731932, 1, 1, '', '', '', '', '6', 4, 1, '', 0, 0), 
('statistics', 'statistics', 'statistics', 'statistics', 'Statistics', '', 1467731932, 1, 1, '', '', '', 'online, statistics', '6', 5, 1, '', 0, 0), 
('voting', 'voting', 'voting', 'voting', 'Voting', '', 1467731932, 1, 1, '', '', '', '', '6', 6, 1, '', 1, 0), 
('banners', 'banners', 'banners', 'banners', 'Banners', '', 1467731932, 1, 1, '', '', '', '', '6', 7, 1, '', 0, 0), 
('seek', 'seek', 'seek', 'seek', 'Search', '', 1467731932, 1, 0, '', '', '', '', '6', 8, 1, '', 0, 0), 
('menu', 'menu', 'menu', 'menu', 'Navigation Bar', '', 1467731932, 0, 1, '', '', '', '', '6', 9, 1, '', 0, 0), 
('feeds', 'feeds', 'feeds', 'feeds', 'RSS-feeds', 'RSS-feeds', 1467731932, 1, 1, '', '', '', '', '6', 10, 1, '', 0, 0), 
('page', 'page', 'page', 'page', 'Page', '', 1467731932, 1, 1, '', '', '', '', '6', 11, 1, '', 1, 0), 
('comment', 'comment', 'comment', 'comment', 'Comment', '', 1467731932, 0, 1, '', '', '', '', '6', 12, 1, '', 0, 0), 
('siteterms', 'page', 'siteterms', 'siteterms', 'Terms & Conditions', '', 1467731932, 1, 1, '', '', '', '', '6', 13, 1, '', 1, 0), 
('freecontent', 'freecontent', 'freecontent', 'freecontent', 'Introduction', '', 1467731932, 0, 1, '', '', '', '', '6', 14, 1, '', 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_1`
--

DROP TABLE IF EXISTS `nv4_en_news_1`;
CREATE TABLE `nv4_en_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_1`
--

INSERT INTO `nv4_en_news_1` VALUES
(1, 1, '1,7,8', 0, 8, 'VINADES', 0, 1277689959, 1277690410, 1, 1277689920, 0, 2, 'Invite to co-operate announcement', 'Invite-to-co-operate-announcement', 'VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing. Include Advertisment, provide hosting services for NukeViet CMS development.', 'hoptac.jpg', '', 1, 1, '6', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_10`
--

DROP TABLE IF EXISTS `nv4_en_news_10`;
CREATE TABLE `nv4_en_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_11`
--

DROP TABLE IF EXISTS `nv4_en_news_11`;
CREATE TABLE `nv4_en_news_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_12`
--

DROP TABLE IF EXISTS `nv4_en_news_12`;
CREATE TABLE `nv4_en_news_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_12`
--

INSERT INTO `nv4_en_news_12` VALUES
(3, 12, '12,7', 0, 8, '', 2, 1277691851, 1287160943, 1, 1277691840, 0, 2, 'HTML 5 review', 'HTML-5-review', 'I have to say that my money used to be on XHTML 2.0 eventually winning the battle for the next great web standard. Either that, or the two titans would continue to battle it out for the forseable future, leading to an increasingly fragmented web.', '', '', 0, 1, '6', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_13`
--

DROP TABLE IF EXISTS `nv4_en_news_13`;
CREATE TABLE `nv4_en_news_13` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_14`
--

DROP TABLE IF EXISTS `nv4_en_news_14`;
CREATE TABLE `nv4_en_news_14` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_14`
--

INSERT INTO `nv4_en_news_14` VALUES
(2, 14, '14,8', 0, 8, '', 1, 1277691366, 1277691470, 1, 1277691360, 0, 2, 'What does WWW mean?', 'What-does-WWW-mean', 'The World Wide Web, abbreviated as WWW and commonly known as the Web, is a system of interlinked hypertext&nbsp; documents accessed via the Internet.', '', '', 0, 1, '2', 1, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_2`
--

DROP TABLE IF EXISTS `nv4_en_news_2`;
CREATE TABLE `nv4_en_news_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_3`
--

DROP TABLE IF EXISTS `nv4_en_news_3`;
CREATE TABLE `nv4_en_news_3` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_4`
--

DROP TABLE IF EXISTS `nv4_en_news_4`;
CREATE TABLE `nv4_en_news_4` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_4`
--

INSERT INTO `nv4_en_news_4` VALUES
(4, 4, '4', 0, 1, 'VOVNews&#x002F;VNA', 0, 1292959020, 1292959513, 1, 1292959020, 0, 2, 'First open-source company starts operation', 'First-open-source-company-starts-operation', 'The Vietnam Open Source Development Joint Stock Company (VINADES.,JSC), the first firm operating in the field of open source in the country, made its debut on February 25.', 'nangly.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(5, 4, '4', 0, 1, '', 0, 1292959490, 1292959664, 1, 1292959440, 0, 2, 'NukeViet 3.0 - New CMS for News site', 'NukeViet-30-New-CMS-for-News-site', 'NukeViet 3.0 is a professional system: VINADES.,JSC founded to maintain and improve NukeViet 3.0 features. VINADES.,JSC co-operated with many professional hosting providers to test compatibility issues.', 'nukeviet-cms.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_5`
--

DROP TABLE IF EXISTS `nv4_en_news_5`;
CREATE TABLE `nv4_en_news_5` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_6`
--

DROP TABLE IF EXISTS `nv4_en_news_6`;
CREATE TABLE `nv4_en_news_6` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_7`
--

DROP TABLE IF EXISTS `nv4_en_news_7`;
CREATE TABLE `nv4_en_news_7` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_7`
--

INSERT INTO `nv4_en_news_7` VALUES
(1, 1, '1,7,8', 0, 8, 'VINADES', 0, 1277689959, 1277690410, 1, 1277689920, 0, 2, 'Invite to co-operate announcement', 'Invite-to-co-operate-announcement', 'VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing. Include Advertisment, provide hosting services for NukeViet CMS development.', 'hoptac.jpg', '', 1, 1, '6', 1, 2, 0, 0, 0), 
(3, 12, '12,7', 0, 8, '', 2, 1277691851, 1287160943, 1, 1277691840, 0, 2, 'HTML 5 review', 'HTML-5-review', 'I have to say that my money used to be on XHTML 2.0 eventually winning the battle for the next great web standard. Either that, or the two titans would continue to battle it out for the forseable future, leading to an increasingly fragmented web.', '', '', 0, 1, '6', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_8`
--

DROP TABLE IF EXISTS `nv4_en_news_8`;
CREATE TABLE `nv4_en_news_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_8`
--

INSERT INTO `nv4_en_news_8` VALUES
(1, 1, '1,7,8', 0, 8, 'VINADES', 0, 1277689959, 1277690410, 1, 1277689920, 0, 2, 'Invite to co-operate announcement', 'Invite-to-co-operate-announcement', 'VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing. Include Advertisment, provide hosting services for NukeViet CMS development.', 'hoptac.jpg', '', 1, 1, '6', 1, 2, 0, 0, 0), 
(2, 14, '14,8', 0, 8, '', 1, 1277691366, 1277691470, 1, 1277691360, 0, 2, 'What does WWW mean?', 'What-does-WWW-mean', 'The World Wide Web, abbreviated as WWW and commonly known as the Web, is a system of interlinked hypertext&nbsp; documents accessed via the Internet.', '', '', 0, 1, '2', 1, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_9`
--

DROP TABLE IF EXISTS `nv4_en_news_9`;
CREATE TABLE `nv4_en_news_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_admins`
--

DROP TABLE IF EXISTS `nv4_en_news_admins`;
CREATE TABLE `nv4_en_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_block`
--

DROP TABLE IF EXISTS `nv4_en_news_block`;
CREATE TABLE `nv4_en_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_block_cat`
--

DROP TABLE IF EXISTS `nv4_en_news_block_cat`;
CREATE TABLE `nv4_en_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_block_cat`
--

INSERT INTO `nv4_en_news_block_cat` VALUES
(1, 0, 4, 'Hot News', 'Hot-News', '', '', 1, '', 1279963759, 1279963759), 
(2, 1, 4, 'Top News', 'Top-News', '', '', 2, '', 1279963766, 1279963766);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_cat`
--

DROP TABLE IF EXISTS `nv4_en_news_cat`;
CREATE TABLE `nv4_en_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `titlesite` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `descriptionhtml` text  COLLATE utf8mb4_unicode_ci,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `ad_block_cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `admins` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=15  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_cat`
--

INSERT INTO `nv4_en_news_cat` VALUES
(1, 0, 'Co-operate', '', 'Co-operate', '', '', '', 0, 2, 5, 0, 'viewcat_page_new', 2, '2,3', 1, 3, 2, 0, '', '', '', 1277689708, 1277689708, '6'), 
(2, 1, 'Careers at NukeViet', '', 'Careers-at-NukeViet', '', '', '', 0, 1, 6, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690086, 1277690259, '6'), 
(3, 1, 'Partners', '', 'Partners', '', '', '', 0, 2, 7, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690142, 1277690291, '6'), 
(4, 0, 'NukeViet news', '', 'NukeViet-news', '', '', '', 0, 1, 1, 0, 'viewcat_page_new', 3, '5,6,7', 1, 3, 2, 0, '', '', '', 1277690451, 1277690451, '6'), 
(5, 4, 'Security issues', '', 'Security-issues', '', '', '', 0, 1, 2, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690497, 1277690564, '6'), 
(6, 4, 'Release notes', '', 'Release-notes', '', '', '', 0, 2, 3, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690588, 1277690588, '6'), 
(7, 4, 'Development team talk', '', 'Development-team-talk', '', '', '', 0, 3, 4, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690652, 1277690652, '6'), 
(8, 0, 'NukeViet community', '', 'NukeViet-community', '', '', '', 0, 3, 8, 0, 'viewcat_page_new', 3, '9,10,11', 1, 3, 2, 0, '', '', '', 1277690748, 1277690748, '6'), 
(9, 8, 'Activities', '', 'Activities', '', '', '', 0, 1, 9, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690765, 1277690765, '6'), 
(10, 8, 'Events', '', 'Events', '', '', '', 0, 2, 10, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690783, 1277690783, '6'), 
(11, 8, 'Faces of week &#x3A;D', '', 'Faces-of-week-D', '', '', '', 0, 3, 11, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690821, 1277690821, '6'), 
(12, 0, 'Lastest technologies', '', 'Lastest-technologies', '', '', '', 0, 4, 12, 0, 'viewcat_page_new', 2, '13,14', 1, 3, 2, 0, '', '', '', 1277690888, 1277690888, '6'), 
(13, 12, 'World wide web', '', 'World-wide-web', '', '', '', 0, 1, 13, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690934, 1277690934, '6'), 
(14, 12, 'Around internet', '', 'Around-internet', '', '', '', 0, 2, 14, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', '', 1277690982, 1277690982, '6');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_config_post`
--

DROP TABLE IF EXISTS `nv4_en_news_config_post`;
CREATE TABLE `nv4_en_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_detail`
--

DROP TABLE IF EXISTS `nv4_en_news_detail`;
CREATE TABLE `nv4_en_news_detail` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourcetext` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_detail`
--

INSERT INTO `nv4_en_news_detail` VALUES
(1, '<p> <span style=\"color: black;\"><span style=\"color: black;\"><font size=\"2\"><span style=\"font-family: verdana,sans-serif;\">VIETNAM OPEN SOURCE DEVELOPMENT COMPANY (VINADES.,JSC)<br /> Head office: Room 2004 – CT2 Nang Huong building, 583 Nguyen Trai street, Hanoi, Vietnam.<br /> Mobile: (+84)4 8587 2007<br /> Fax: (+84) 4 3550 0914<br /> Website: <a f8f55ee40942436149=\"true\" href=\"http://www.vinades.vn/\" target=\"_blank\">www.vinades.vn</a> - <a f8f55ee40942436149=\"true\" href=\"http://www.nukeviet.vn/\" target=\"_blank\">www.nukeviet.vn</a></span></font></span></span></p><div h4f82558737983=\"nukeviet.vn\" style=\"display: inline; cursor: pointer; padding-right: 16px; width: 16px; height: 16px;\"> <span style=\"color: black;\"><span style=\"color: black;\"><font size=\"2\"><span style=\"font-family: verdana,sans-serif;\">&nbsp;</span></font></span></span></div><br /><p> <span style=\"color: black;\"><span style=\"color: black;\"><font size=\"2\"><span style=\"font-family: verdana,sans-serif;\">Email: <a href=\"mailto:contact@vinades.vn\" target=\"_blank\">contact@vinades.vn</a><br /> <br /> <br /> Dear valued customers and partners,<br /> <br /> VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing.<br /> <br /> NukeViet is a Content Management System (CMS). 1st general purpose CMS developed by Vietnamese community. It have so many pros. Ex: Biggest community in VietNam, pure Vietnamese, easy to use, easy to develop...<br /> <br /> NukeViet 3 is lastest version of NukeViet and it still developing but almost complete with many advantage features.<br /> <br /> With respects to invite hosting - domain providers, and all company that pay attension to NukeViet in bussiness co-operate.<br /> <br /> Co-operate types:<br /> <br /> 1. Website advertisement, banners exchange, links:<br /> a. Description:<br /> Website advertising &amp; communication channels.<br /> On each release version of NukeViet.<br /> b. Benefits:<br /> Broadcast to all end users on both side.<br /> Reduce advertisement cost.<br /> c. Warranties:<br /> Place advertisement banner of partners on both side.<br /> Open sub-forum at NukeViet.VN to support end users who using hosting services providing by partners.<br /> <br /> 2. Provide host packet for NukeViet development testing purpose:<br /> <br /> a. Description:<br /> Sign the contract and agreements.<br /> Partners provide all types of hosting packet for VINADES.,JSC. Each type at least 1 re-sale packet.<br /> VINADES.,JSC provide an certificate verify host providing by partner compartable with NukeViet.<br /> b. Benefits:<br /> Expand market.<br /> Reduce cost, improve bussiness value.<br /> c. Warranties:<br /> Partner provide free hosting packet for VINADES.,JSC to test NukeViet compatibility.<br /> VINADES.JSC annoucement tested result to community.<br /> <br /> 3. Support end users:<br /> a. Description:<br /> Co-operate to solve problem of end user.<br /> Partners send end user requires about NukeViet CMS to VINADES.,JSC. VINADES also send user requires about hosting services to partners.<br /> b. Benefits:<br /> Reduce cost, human resources to support end users.<br /> Support end user more effective.<br /> c. Warranties:<br /> Solve end user requires as soon as possible.<br /> <br /> 4. Other types:<br /> Besides, as a publisher of NukeViet CMS, we also place advertisements on software user interface, sample articles in each release version. With thousands of downloaded hits each release version, we believe that it is the most effective advertisement type to webmasters.<br /> If partners have any ideas about new co-operate types. You are welcome and feel free to send specifics to us. Our slogan is &quot;Co-operate for development&quot;.<br /> <br /> We look forward to co-operating with you.<br /> <br /> Sincerely,<br /> <br /> VINADES.,JSC</span></font></span></span></p>', '', 2, 0, 1, 1, 1, 0), 
(2, '<p> With a web browser, one can view web pages&nbsp; that may contain text, images, videos, and other multimedia&nbsp; and navigate between them by using hyperlinks. Using concepts from earlier hypertext systems, British engineer and computer scientist Sir Tim Berners-Lee, now the Director of the World Wide Web Consortium, wrote a proposal in March 1989 for what would eventually become the World Wide Web. He was later joined by Belgian computer scientist Robert Cailliau while both were working at CERN in Geneva, Switzerland. In 1990, they proposed using &quot;HyperText to link and access information of various kinds as a web of nodes in which the user can browse at will&quot;, and released that web in December.<br /> <br /> &quot;The World-Wide Web (W3) was developed to be a pool of human knowledge, which would allow collaborators in remote sites to share their ideas and all aspects of a common project.&quot;. If two projects are independently crea-ted, rather than have a central figure make the changes, the two bodies of information could form into one cohesive piece of work.</p><p> For more detail. See <a href=\"http://en.wikipedia.org/wiki/World_Wide_Web\" target=\"_blank\">Wikipedia</a></p>', '', 1, 0, 1, 1, 1, 0), 
(3, '<p> But now that the W3C has admitted defeat, and abandoned <span class=\"caps\">XHTML</span> 2.0, there’s now no getting away f-rom the fact that <span class=\"caps\">HTML</span> 5 is the future. As such, I’ve now spent some time taking a look at this emerging standard, and hope you’ll endulge my ego by taking a glance over my thoughts on the matter.</p><p> Before I get started though, I have to say that I’m very impressed by what I’ve seen. It’s a good set of standards that are being cre-ated, and I hope that they will gradually be adopted over the next few years.</p><h2> New markup</h2><p> <span class=\"caps\">HTML</span> 5 introduces some new markup elements to encourage better structure within documents. The most important of these is &lt;section&gt;, which is used to define a hierarchy within a document. Sections can be nested to define subsections, and each section can be broken up into &lt;header&gt; and &lt;footer&gt; areas.</p><p> The important thing about this addition is that it removes the previous dependancy on &lt;h1&gt;, &lt;h2&gt; and related tags to define structure. Within each &lt;section&gt;, the top level heading is always &lt;h1&gt;. You can use as many &lt;h1&gt; tags as you like within your content, so long as they are correctly nested within &lt;section&gt; tags.</p><p> There’s a plethora of other new tags, all of which seem pretty useful. The best thing about all of this, however, is that there’s no reason not to start using them right away. There’s a small piece of JavaScript that’s needed to make Internet Explorer behave, but aside f-rom that it’s all good. More details about this hack are available at <a href=\"http://www.diveintohtml5.org/\">http://www.diveintohtml5.org</a></p><h2> Easier media embedding</h2><p> <span class=\"caps\">HTML</span> 5 defines some new tags that will make it a lot easier to embed video and audio into pages. In the same way that images are embedded using &lt;img&gt; tags, so now can video and audio files be embedded using &lt;video&gt; and &lt;audio&gt;.</p><p> I don’t think than anyone is going to complain about these new features. They free us f-rom relying on third-party plugins, such as Adobe Flash, for such simple activities such as playing video.</p><p> Unfortunately, due to some annoying licensing conditions and a lack of support for the open-source Theora codec, actually using these tags at the moment requires that videos are encoded in two different formats. Even then, you’ll still need to still provide an Adobe Flash fallback for Internet Explorer.</p><p> You’ll need to be pretty devoted to <span class=\"caps\">HTML</span> 5 to use these tags yet…</p><h2> Relaxed markup rules</h2><p> This is one thorny subject. You know how we’ve all been so good recently with our well-formed <span class=\"caps\">XHTML</span>, quoting those attributes and closing those tags? Now there’s no need to, apparently…</p><p> On the surface, this seems like a big step backwards into the bad days of tag soup. However, if you dig deeper, the reasoning behind this decision goes something like this:</p><ol> <li> It’s unnacceptable to crash out an entire <span class=\"caps\">HTML</span> page just because of a simple <span class=\"caps\">XML</span> syntax error.</li> <li> This means that browsers cannot use an <span class=\"caps\">XML</span> parser, and must instead use a HTML-aware fault-tolerant parser.</li> <li> For consistency, all browsers should handle any such “syntax errors” (such as unquoted attributes and unclosed tags), in the same way.</li> <li> If all browsers are behaving in the same way, then unquoted attributes and unclosed tags are not really syntax errors any more. In fact, by leaving them out of our pages, we can save a few bytes!</li></ol><p> This isn’t to say that you have to throw away those <span class=\"caps\">XHTML</span> coding habits. It’s still all valid <span class=\"caps\">HTML</span> 5. In fact, if you really want to be strict, you can set a different content-type header to enforce well-formed <span class=\"caps\">XHTML</span>. But for most people, we’ll just carry on coding well-formed <span class=\"caps\">HTML</span> with the odd typo, but no longer have to worry about clients screaming at us when the perfectly-rendered page doesn’t validate.</p><h2> So what now?</h2><p> The <span class=\"caps\">HTML</span> 5 specification is getting pretty close to stable, so it’s now safe to use bits of this new standard in your code. How much you use is entirely a personal choice. However, we should all get used to the new markup over the next few years, because <span class=\"caps\">HTML</span> 5 is assuredly here to stay.</p><p> Myself, I’ll be switching to the new doctype and using the new markup for document sections in my code. This step involves very little effort and does a good job of showing support for the new specification.</p><p> The new media tags are another matter. Until all platforms support a single video format, it’s simply not sustainable to be transcoding all videos into two filetypes. When this is coupled with having to provide a Flash fallback, it all seems like a pretty poor return on investment.</p><p> These features will no doubt become more useable over the next few years, as newer browser take the place of old. One day, hopefully, we’ll be able write clean, semantic pages without having to worry about backwards-compatibility.</p><p> Part of this progress relies on web developers using these new standards in our pages. By adopting new technology, we show our support for the standards it represents and place pressure on browser vendors to adhere to those standards. It’s a bit of effort in the short term, but in the long term it will pay dividends.</p>\', \'http://www.etianen.com/blog/developers/2010/2/html-5-review/', '', 2, 0, 1, 1, 1, 0), 
(4, '<p> <span>The Hanoi-based company will further develop and popularise an open source content management system best known as NukeViet in the country. </span></p><p> <span>VINADES Chairman Nguyen Anh Tu said NukeViet is totally free and users can download the product at www.nukeviet.vn. </span></p><p> <span>NukeViet has been widely used across the country over the past five years. The system, built on PHP-Nuke and MySQL database, enables users to easily post and manage files on the Internet or Intranet.</span></p>', '', 0, 0, 1, 1, 1, 0), 
(5, '<p style=\"text-align: justify;\"> NukeViet also testing by many experienced webmasters to optimize system features. NukeViet&#039;s core team are programming enthusiasts. All of them want to make NukeViet become the best and most popular open source CMS.</p><p style=\"text-align: justify;\"> <strong>NukeViet 3.0 is a powerful system:</strong><br /> Learn by experiences f-rom NukeViet 2.0, NukeViet 3.0 build ground up on latest web technologies, allow you easily cre-ate portal, online news express, social network, e commerce system.<br /> NukeViet 3.0 can process huge amount of data. It was used by many companies, corporation&#039;s website with millions of news entries with high traffic.<br /> <br /> <strong>NukeViet 3.0 is easy to use system:</strong><br /> NukeViet allow you easily to customize and instantly use without any line of code. As developers, NukeViet help you build your own modules rapidly.</p><h2 style=\"text-align: justify;\"> NukeViet 3.0 features:</h2><p style=\"text-align: justify;\"> <strong>Technology bases:</strong><br /> NukeViet 3.0 using PHP 5 and MySQL 5 as main programming languages. XTemplate and jQuery for use Ajax f-rom system core.<br /> NukeViet 3.0 is fully validated with xHTML 1.0, CSS 2.1 and compatible with all major browsers.<br /> NukeViet 3.0 layout website using grid CSS framework like BluePrintCSS for design templates rapidly.<br /> <br /> NukeViet 3.0 has it own core libraries and it is platform independent. You can build your own modules with basic knowledge of PHP and MySQL.<br /> <br /> <strong>Module structure:</strong><br /> NukeViet 3.0 re-construct module structure. All module files packed into a particular folder. It&#039;s also define module block and module theme for layout modules in many ways.<br /> <br /> NukeViet 3.0 support modules can be multiply. We called it abstract modules. It help users automatic cre-ate many modules without any line of code f-rom any exists module which support cre-ate abstract modules.<br /> <br /> NukeViet 3.0 support automatic setup modules, blocks, themes f-rom Admin Control Panel. It&#039;s also allow you to share your modules by packed it into packets. NukeViet allow grant, deny access or even re-install, de-lete module.<br /> <br /> <strong>Multi language:</strong><br /> NukeViet 3 support multi languages in 2 types. Multi interface languages and multi database languages. It had features support administrators to build new languages. In NukeViet 3, admin language, user language, interface language, database language are separate for easily build multi languages systems.<br /> <br /> <strong>Right:</strong><br /> All manage features only access in admin area. NukeViet 3.0 allow grant access by module and language. It also allow cre-ate user groups and grant access modules by group.<br /> <br /> <strong>Themes:</strong><br /> NukeViet 3.0 support automatic install and uninstall themes. You can easily customize themes in module and module&#039;s functions. NukeViet store HTML, CSS code separately f-rom PHP code to help designers rapidly layout website.<br /> <br /> <strong>Customize website using blocks</strong><br /> A block can be a widget, advertisement pictures or any defined data. You can place block in many positions visually by drag and d-rop or argument it in Admin Control Panel.<br /> <br /> <strong>Securities:</strong><br /> NukeViet using security filters to filter data upload.<br /> Logging and control access f-rom many search engine as Google, Yahoo or any search engine.<br /> Anti spam using Captcha, anti flood data...<br /> NukeViet 3.0 has logging systems to log and track information about client to prevent attack.<br /> NukeViet 3.0 support automatic up-date to fix security issues or upgrade your website to latest version of NukeViet.<br /> <br /> <strong>Database:</strong><br /> You can backup database and download backup files to restore database to any point you restored your database.<br /> <br /> <strong>Control errors report</strong><br /> You can configure to display each type of error only one time. System then sent log files about this error to administrator via email.<br /> <br /> <strong>SEO:</strong><br /> Support SEO link<br /> Manage and customize website title<br /> Manage meta tag<br /> <br /> Support keywords for cre-ate statistic via search engine<br /> <br /> <strong>Prepared for integrate with third party application</strong><br /> NukeViet 3.0 has it own user database and many built-in methods to connect with many forum application. PHPBB or VBB can integrate and use with NukeViet 3.0 by single click.<br /> <br /> <strong>Distributed login</strong><br /> NukeViet support login by OpenID. Users can login to your website by accounts f-rom popular and well-known provider, such as Google, Yahoo or other OpenID providers. It help your website more accessible and reduce user&#039;s time to filling out registration forms.<br /> <br /> Download NukeViet 3.0: <a href=\"http://code.google.com/p/nuke-viet/downloads/list\">http://code.google.com/p/nuke-viet/downloads/list</a><br /> Website: <a href=\"http://nukeviet.vn/\">http://nukeviet.vn</a></p>', '', 2, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_logs`
--

DROP TABLE IF EXISTS `nv4_en_news_logs`;
CREATE TABLE `nv4_en_news_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_rows`
--

DROP TABLE IF EXISTS `nv4_en_news_rows`;
CREATE TABLE `nv4_en_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_rows`
--

INSERT INTO `nv4_en_news_rows` VALUES
(1, 1, '1,7,8', 0, 8, 'VINADES', 0, 1277689959, 1277690410, 1, 1277689920, 0, 2, 'Invite to co-operate announcement', 'Invite-to-co-operate-announcement', 'VINADES.,JSC was founded in order to professionalize NukeViet opensource development and release. We also using NukeViet in our bussiness projects to make it continue developing. Include Advertisment, provide hosting services for NukeViet CMS development.', 'hoptac.jpg', '', 1, 1, '6', 1, 2, 0, 0, 0), 
(2, 14, '14,8', 0, 8, '', 1, 1277691366, 1277691470, 1, 1277691360, 0, 2, 'What does WWW mean?', 'What-does-WWW-mean', 'The World Wide Web, abbreviated as WWW and commonly known as the Web, is a system of interlinked hypertext&nbsp; documents accessed via the Internet.', '', '', 0, 1, '2', 1, 0, 0, 0, 0), 
(3, 12, '12,7', 0, 8, '', 2, 1277691851, 1287160943, 1, 1277691840, 0, 2, 'HTML 5 review', 'HTML-5-review', 'I have to say that my money used to be on XHTML 2.0 eventually winning the battle for the next great web standard. Either that, or the two titans would continue to battle it out for the forseable future, leading to an increasingly fragmented web.', '', '', 0, 1, '6', 1, 2, 0, 0, 0), 
(4, 4, '4', 0, 1, 'VOVNews&#x002F;VNA', 0, 1292959020, 1292959513, 1, 1292959020, 0, 2, 'First open-source company starts operation', 'First-open-source-company-starts-operation', 'The Vietnam Open Source Development Joint Stock Company (VINADES.,JSC), the first firm operating in the field of open source in the country, made its debut on February 25.', 'nangly.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(5, 4, '4', 0, 1, '', 0, 1292959490, 1292959664, 1, 1292959440, 0, 2, 'NukeViet 3.0 - New CMS for News site', 'NukeViet-30-New-CMS-for-News-site', 'NukeViet 3.0 is a professional system: VINADES.,JSC founded to maintain and improve NukeViet 3.0 features. VINADES.,JSC co-operated with many professional hosting providers to test compatibility issues.', 'nukeviet-cms.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_sources`
--

DROP TABLE IF EXISTS `nv4_en_news_sources`;
CREATE TABLE `nv4_en_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `logo` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_sources`
--

INSERT INTO `nv4_en_news_sources` VALUES
(1, 'Wikipedia', 'http://www.wikipedia.org', '', 1, 1277691366, 1277691366), 
(2, 'Enlightened Website Development', 'http://www.etianen.com', '', 2, 1277691851, 1277691851);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_tags`
--

DROP TABLE IF EXISTS `nv4_en_news_tags`;
CREATE TABLE `nv4_en_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_tags`
--

INSERT INTO `nv4_en_news_tags` VALUES
(1, 0, 'vinades', '', '', 'VINADES'), 
(2, 0, 'web', '', '', 'Web'), 
(3, 0, 'html5', '', '', 'HTML5'), 
(4, 0, 'nguyen-anh-tu', '', '', 'Nguyen Anh Tu'), 
(5, 0, 'nukeviet', '', '', 'NukeViet');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_tags_id`
--

DROP TABLE IF EXISTS `nv4_en_news_tags_id`;
CREATE TABLE `nv4_en_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `id_tid` (`id`,`tid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_news_tags_id`
--

INSERT INTO `nv4_en_news_tags_id` VALUES
(1, 1, 'VINADES'), 
(2, 2, 'Web'), 
(3, 3, 'HTML5'), 
(4, 1, 'VINADES'), 
(4, 4, 'Nguyen Anh Tu'), 
(5, 5, 'NukeViet'), 
(5, 1, 'VINADES');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_topics`
--

DROP TABLE IF EXISTS `nv4_en_news_topics`;
CREATE TABLE `nv4_en_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_page`
--

DROP TABLE IF EXISTS `nv4_en_page`;
CREATE TABLE `nv4_en_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_page_config`
--

DROP TABLE IF EXISTS `nv4_en_page_config`;
CREATE TABLE `nv4_en_page_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_page_config`
--

INSERT INTO `nv4_en_page_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_referer_stats`
--

DROP TABLE IF EXISTS `nv4_en_referer_stats`;
CREATE TABLE `nv4_en_referer_stats` (
  `host` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_searchkeys`
--

DROP TABLE IF EXISTS `nv4_en_searchkeys`;
CREATE TABLE `nv4_en_searchkeys` (
  `id` varchar(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `skey` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_siteterms`
--

DROP TABLE IF EXISTS `nv4_en_siteterms`;
CREATE TABLE `nv4_en_siteterms` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_siteterms`
--

INSERT INTO `nv4_en_siteterms` VALUES
(1, 'Terms & Conditions', 'Terms-Conditions', '', '', 0, '', '<h2><strong>Term no</strong><strong> 1: Collect information</strong></h2><strong>1.1. Collecting information automatically.</strong><br />Like the other modern websites, Websites will collect IP address and some information of the standard website like: browser, pages that you access to websites for process using services by desktop, laptop, computer and network devices, etc. It aims to analyze information for privacy and keeping safe mode the system.<br /><strong>1.2. Collecting your information through an account.</strong><br />All information of your account (creating a new account, contacting to us, and so on) will be stored in profile for caring customer services later.<br /><strong>1.3. Collecting information through setting up cookies.</strong><br />Like the other modern websites, when you access to websites, we (or monitoring tools; or the statistics of website activities that provided by partners ) will create some profiles that named Cookies on hard-disk or memory of your computer. One of some Cookies may be exist with the long time to become convenient process using. For example, saving your email in login page to avoid login again, ect.<br /><strong>1.4. Collecting and storing information in the last.</strong><h3>You can change the private information any time, however, we will save in all information that changed to prevent the erase traces of illegal activities.</h3><h2><br /><strong>Term no</strong><strong> 2: Storing and protecting information.</strong></h2>Almost collected information will be stored in us database system.<br />We protect personal information by using some tools as password, firewall, encryption, and with some other tools that is license for accessing and suitable for data management process. For example, you and staffs must be responsibility for information processing through identifying steps in private information.<h2><br /><strong>Term no</strong><strong> 3: Using information</strong></h2>Collected information will be used to:<ul>	<li>Supplying support services &amp; customer care.</li>	<li>Transaction payment and Payment Notifications will send when a new payment is created</li>	<li>Handling complaints, charges &amp; Troubleshooting.</li>	<li>Stopping any forbidden or illegal act and must guarantee to follow the policies in &quot;User agreement”</li>	<li><a name=\"_GoBack\"></a> Measurement, upgrading &amp; improving services, content and form of the website.</li>	<li>Sending information to user about Marketing&#039;s Programs, announcements and promotional programs.</li>	<li>Comparison of the accuracy of your personal information in the process of checking with third parties.</li></ul><h2><br /><strong>Term no 4: Receiving information from partners</strong></h2>When using payment and transactions tools via the internet, we can receive more information about you such as your username address, email, bank account number ... We check that information with our user database to confirm whether you are the customer of us or not in order to enable the implementation of the service is convenient for you.<br />The received information will be secured as the information that we collected directly from you.<h2><br /><strong>Term no 5: Sharing information with the third party</strong></h2>We will not share your personal information, financial information... for the 3rd party, unless we have your consent or when we are forced to comply with the law or in case of having the requests from government agencies having jurisdiction.<h2><br /><strong>Term no 6: Changing the privacy policy</strong></h2>This Privacy Policy may change from time to time. We will not reduce your rights under this Privacy Policy without your explicit consent. We will post any changes to this Privacy Policy on this website and if the changes are significant, we will provide a more prominent notice (including information email message about the change of the Privacy Policy for certain services).<br /><br />&nbsp;<div style=\"text-align: right;\">Tham khảo từ website <a href=\"http://webnhanh.vn/vi/thiet-ke-web/detail/Chinh-sach-bao-mat-Quyen-rieng-tu-Privacy-Policy-2147/\">webnhanh.vn</a><br />&nbsp;</div>', '', 0, '4', '', 0, 1, 1, 1467731932, 1467731932, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_siteterms_config`
--

DROP TABLE IF EXISTS `nv4_en_siteterms_config`;
CREATE TABLE `nv4_en_siteterms_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_siteterms_config`
--

INSERT INTO `nv4_en_siteterms_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_voting`
--

DROP TABLE IF EXISTS `nv4_en_voting`;
CREATE TABLE `nv4_en_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_voting`
--

INSERT INTO `nv4_en_voting` VALUES
(2, 'Do you know about Nukeviet 3?', '', 1, 1, '6', 1275318563, 0, 1), 
(3, 'What are you interested in open source?', '', 1, 1, '6', 1275318563, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_voting_rows`
--

DROP TABLE IF EXISTS `nv4_en_voting_rows`;
CREATE TABLE `nv4_en_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `url` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_en_voting_rows`
--

INSERT INTO `nv4_en_voting_rows` VALUES
(5, 2, 'A whole new sourcecode for the web.', '', 0), 
(6, 2, 'Open source, free to use.', '', 0), 
(7, 2, 'Use of xHTML, CSS and Ajax support', '', 0), 
(8, 2, 'All the comments on', '', 0), 
(9, 3, 'constantly improved, modified by the whole world.', '', 0), 
(10, 3, 'To use the free of charge.', '', 0), 
(11, 3, 'The freedom to explore, modify at will.', '', 0), 
(12, 3, 'Match to learning and research because the freedom to modify at will.', '', 0), 
(13, 3, 'All comments on', '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_extension_files`
--

DROP TABLE IF EXISTS `nv4_extension_files`;
CREATE TABLE `nv4_extension_files` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lastmodified` int(11) unsigned NOT NULL DEFAULT '0',
  `duplicate` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_googleplus`
--

DROP TABLE IF EXISTS `nv4_googleplus`;
CREATE TABLE `nv4_googleplus` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `idprofile` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  UNIQUE KEY `idprofile` (`idprofile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_language`
--

DROP TABLE IF EXISTS `nv4_language`;
CREATE TABLE `nv4_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_language_file`
--

DROP TABLE IF EXISTS `nv4_language_file`;
CREATE TABLE `nv4_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_file` varchar(200)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `langtype` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_logs`
--

DROP TABLE IF EXISTS `nv4_logs`;
CREATE TABLE `nv4_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_name` varchar(150)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_key` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_action` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_acess` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_notification`
--

DROP TABLE IF EXISTS `nv4_notification`;
CREATE TABLE `nv4_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` mediumint(8) unsigned NOT NULL,
  `send_from` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(1) unsigned NOT NULL,
  `language` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `obid` int(11) unsigned NOT NULL DEFAULT '0',
  `type` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `view` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_plugin`
--

DROP TABLE IF EXISTS `nv4_plugin`;
CREATE TABLE `nv4_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_plugin`
--

INSERT INTO `nv4_plugin` VALUES
(1, 'qrcode.php', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_sessions`
--

DROP TABLE IF EXISTS `nv4_sessions`;
CREATE TABLE `nv4_sessions` (
  `session_id` varchar(50)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_sessions`
--

INSERT INTO `nv4_sessions` VALUES
('3jkjprele9k0j2ocp0tet6akm0', 0, 'guest', 1467731973);


-- ---------------------------------------


--
-- Table structure for table `nv4_setup`
--

DROP TABLE IF EXISTS `nv4_setup`;
CREATE TABLE `nv4_setup` (
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `tables` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_extensions`
--

DROP TABLE IF EXISTS `nv4_setup_extensions`;
CREATE TABLE `nv4_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `is_virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table_prefix` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `version` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_setup_extensions`
--

INSERT INTO `nv4_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'siteterms', 0, 0, 'page', 'siteterms', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(24, 'module', 'users', 1, 1, 'users', 'users', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(29, 'module', 'menu', 0, 0, 'menu', 'menu', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(312, 'module', 'freecontent', 0, 0, 'freecontent', 'freecontent', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(307, 'theme', 'default', 0, 0, 'default', 'default', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', ''), 
(311, 'theme', 'mobile_default', 0, 0, 'mobile_default', 'mobile_default', '4.0.29 1463652000', 1467731932, 'VINADES (contact@vinades.vn)', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_language`
--

DROP TABLE IF EXISTS `nv4_setup_language`;
CREATE TABLE `nv4_setup_language` (
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_setup_language`
--

INSERT INTO `nv4_setup_language` VALUES
('en', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_dir`
--

DROP TABLE IF EXISTS `nv4_upload_dir`;
CREATE TABLE `nv4_upload_dir` (
  `did` mediumint(8) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=16  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_upload_dir`
--

INSERT INTO `nv4_upload_dir` VALUES
(0, '', 0, 3, 100, 150, 90), 
(1, 'uploads', 0, 0, 0, 0, 0), 
(2, 'uploads/about', 0, 0, 0, 0, 0), 
(3, 'uploads/banners', 0, 0, 0, 0, 0), 
(4, 'uploads/contact', 0, 0, 0, 0, 0), 
(5, 'uploads/freecontent', 0, 0, 0, 0, 0), 
(6, 'uploads/menu', 0, 0, 0, 0, 0), 
(7, 'uploads/news', 0, 0, 0, 0, 0), 
(8, 'uploads/news/2016_01', 0, 0, 0, 0, 0), 
(9, 'uploads/news/source', 0, 0, 0, 0, 0), 
(10, 'uploads/news/temp_pic', 0, 0, 0, 0, 0), 
(11, 'uploads/news/topics', 0, 0, 0, 0, 0), 
(12, 'uploads/page', 0, 0, 0, 0, 0), 
(13, 'uploads/siteterms', 0, 0, 0, 0, 0), 
(14, 'uploads/users', 0, 0, 0, 0, 0), 
(15, 'uploads/users/groups', 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_file`
--

DROP TABLE IF EXISTS `nv4_upload_file`;
CREATE TABLE `nv4_upload_file` (
  `name` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ext` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(5)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alt` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_users`
--

DROP TABLE IF EXISTS `nv4_users`;
CREATE TABLE `nv4_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(80)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `gender` char(1)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `photo` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text  COLLATE utf8mb4_unicode_ci,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `passlostkey` varchar(50)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_openid` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  `safemode` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `safekey` varchar(40)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users`
--

INSERT INTO `nv4_users` VALUES
(1, 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '{SSHA}EfO34Uv4THtWyZb2PeGHypdrGDJ3YnVy', 'dungpv20101292@gmail.com', 'admin', '', '', '', 0, '', 1467731970, 'dungdeptrai', 'chuan', '', 0, 1, '', 1, '', 1467731970, '', '', '', 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_users_config`
--

DROP TABLE IF EXISTS `nv4_users_config`;
CREATE TABLE `nv4_users_config` (
  `config` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_config`
--

INSERT INTO `nv4_users_config` VALUES
('access_admin', 'a:6:{s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|11223344|654321|696969|1234567|12345678|87654321|123456789|23456789|1234567890|66666666|68686868|66668888|88888888|99999999|999999999|1234569|12345679|aaaaaa|abc123|abc123@|abc@123|admin123|admin123@|admin@123|nuke123|nuke123@|nuke@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman|hoilamgi|khongbiet|khongco|khongcopass', 1467731932), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1467731932), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1467731932), 
('avatar_width', '80', 1467731932), 
('avatar_height', '80', 1467731932), 
('active_group_newusers', '0', 1467731932), 
('siteterms_en', '<p style=\"text-align:center;\"> <strong>Website usage terms and conditions – sample template</strong></p><p> Welcome to our website. If you continue to browse and use this website you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern [business name]’s relationship with you in relation to this website.<br /> The term ‘[business name]’ or ‘us’ or ‘we’ refers to the owner of the website whose registered office is [address]. Our company registration number is [company registration number and place of registration]. The term ‘you’ refers to the user or viewer of our website.<br /> The use of this website is subject to the following terms of use:<br /> • The content of the pages of this website is for your general information and use only. It is subject to change without notice.<br /> • Neither we nor any third parties provide any warranty or guarantee as to the accuracy, timeliness, performance, completeness or suitability of the information and materials found or offered on this website for any particular purpose. You acknowledge that such information and materials may contain inaccuracies or errors and we expressly exclude liability for any such inaccuracies or errors to the fullest extent permitted by law.<br /> • Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services or information available through this website meet your specific requirements.<br /> • This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.<br /> • All trademarks reproduced in this website, which are not the property of, or licensed to the operator, are acknowledged on the website.<br /> • Unauthorised use of this website may give rise to a claim for damages and/or be a criminal offence.<br /> • fr0m time to time this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).<br /> • You may not crea-te a link to this website fr0m another website or document without [business name]’s prior written consent.<br /> • Your use of this website and any dispute arising out of such use of the website is subject to the laws of England, Scotland and Wales.</p>', 1274757617);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_field`
--

DROP TABLE IF EXISTS `nv4_users_field`;
CREATE TABLE `nv4_users_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'textbox',
  `field_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sql_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `match_regex` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_callback` varchar(75)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_groups`
--

DROP TABLE IF EXISTS `nv4_users_groups`;
CREATE TABLE `nv4_users_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `content` text  COLLATE utf8mb4_unicode_ci,
  `group_type` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '0:Sys, 1:approval, 2:public',
  `group_color` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_avatar` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  `idsite` int(11) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `config` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `ktitle` (`title`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_groups`
--

INSERT INTO `nv4_users_groups` VALUES
(1, 'Super admin', '', 'Super Admin', '', 0, '', '', 0, 1467731932, 0, 1, 1, 0, 1, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(2, 'General admin', '', 'General Admin', '', 0, '', '', 0, 1467731932, 0, 2, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(3, 'Module admin', '', 'Module Admin', '', 0, '', '', 0, 1467731932, 0, 3, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(4, 'Users', '', 'Users', '', 0, '', '', 0, 1467731932, 0, 4, 1, 0, 1, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(7, 'New Users', '', 'New Users', '', 0, '', '', 0, 1467731932, 0, 5, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(5, 'Guest', '', 'Guest', '', 0, '', '', 0, 1467731932, 0, 6, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(6, 'All', '', 'All', '', 0, '', '', 0, 1467731932, 0, 7, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(10, 'NukeViet-Fans', '', 'NukeViet-Fans', '', 2, '', '', 1, 1467731932, 0, 8, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(11, 'NukeViet-Admins', '', 'NukeViet-Admins', '', 2, '', '', 0, 1467731932, 0, 9, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(12, 'NukeViet-Programmers', '', 'NukeViet-Programmers', '', 1, '', '', 0, 1467731932, 0, 10, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}');


-- ---------------------------------------


--
-- Table structure for table `nv4_users_groups_users`
--

DROP TABLE IF EXISTS `nv4_users_groups_users`;
CREATE TABLE `nv4_users_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `is_leader` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `approved` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `data` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_groups_users`
--

INSERT INTO `nv4_users_groups_users` VALUES
(1, 1, 1, 1, '0');


-- ---------------------------------------


--
-- Table structure for table `nv4_users_info`
--

DROP TABLE IF EXISTS `nv4_users_info`;
CREATE TABLE `nv4_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_info`
--

INSERT INTO `nv4_users_info` VALUES
(1);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_openid`
--

DROP TABLE IF EXISTS `nv4_users_openid`;
CREATE TABLE `nv4_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `opid` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_question`
--

DROP TABLE IF EXISTS `nv4_users_question`;
CREATE TABLE `nv4_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_question`
--

INSERT INTO `nv4_users_question` VALUES
(1, 'What is the first name of your favorite uncle?', 'en', 1, 1274841115, 1274841115), 
(2, 'whe-re did you meet your spouse', 'en', 2, 1274841123, 1274841123), 
(3, 'What is your oldest cousin&#039;s name?', 'en', 3, 1274841131, 1274841131), 
(4, 'What is your youngest child&#039;s username?', 'en', 4, 1274841142, 1274841142), 
(5, 'What is your oldest child&#039;s username?', 'en', 5, 1274841150, 1274841150), 
(6, 'What is the first name of your oldest niece?', 'en', 6, 1274841158, 1274841158), 
(7, 'What is the first name of your oldest nephew?', 'en', 7, 1274841167, 1274841167), 
(8, 'What is the first name of your favorite aunt?', 'en', 8, 1274841175, 1274841175), 
(9, 'whe-re did you spend your honeymoon?', 'en', 9, 1274841183, 1274841183);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_reg`
--

DROP TABLE IF EXISTS `nv4_users_reg`;
CREATE TABLE `nv4_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(80)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checknum` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `users_info` text  COLLATE utf8mb4_unicode_ci,
  `openid_info` text  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;